# -*- coding: utf-8 -*-
"""
    Pricing_aware_MEC_offloading.simulation
    ~~~~~~~~~~~~~~~~~~~~~~~~~

    Simulation for the Pricing_aware_MEC_offloading

    :copyright: (c) 2019 by Giorgos Mitsis.
    :license: MIT License, see LICENSE for more details.
"""

from helper_functions4 import *
from game_functions4 import *
from plots import *

from parameters4 import *


def main(params):
    expected_utility_converging = []
    pricing_converging = []
    PoF_converging = []
    Pof_weight_converging = []
    energy_converging = []
    times_converging = []
    # b_old is only used to store the previous offloading decision to find convergence
    # b_old仅用于存储之前的卸载决策以求得收敛
    iterations = 0
    # b_converging = [b.copy()]
    # 产生第一个预期效用
    # to generate the first expected utility
    b_converging = []
    expected_utility = []
    b = 0
    for i in range(1000):
        b, b_old = initialize(**params)
        b_converging = [b.copy()]
        expected_utility = np.empty_like(b)
        a = np.zeros_like(b)
        for i in range(len(b)):
            expected_utility[i] = -utility_function(b[i], i, b, a, **params)
        print("价格最大值 : ", max(a))
        expected_utility_converging.append(expected_utility.copy())
        pricing_converging.append(calculate_costs(b, **params))
        PoF_converging.append(calculate_PoF(b, **params))
        Pof_weight_converging.append(calculate_PoFweighting(b, **params))
        energy_converging.append(calculate_energy(b, **params))
        times_converging.append(calculate_times(b, **params))

    # while not converged:
    #
    #     # if constant offloading, just calculate the expected utility for the specified offloading amount
    #     # 如果卸载是恒定的，只需计算具体卸载量的期望效用
    #     if params["CONSTANT_OFFLOADING"]:
    #         expected_utility = np.empty_like(b)
    #         for i in range(len(b)):
    #             # 没有改变卸载量的值，直接计算其期望
    #             expected_utility[i] = -utility_function(b[i], i, b, **params)
    #         b_old = b.copy() # to converge
    #     else:
    #         b, expected_utility = play_offloading_game(b, a, **params)
    #
    #     # check if the game has reached a Nash equilibrium
    #     converged = game_converged(b, b_old, **params)
    #
    #     b_old = b.copy()
    #
    #     iterations += 1
    #     b_converging.append(b.copy())
    #     expected_utility_converging.append(expected_utility.copy())
    #     pricing_converging.append(calculate_costs(b, **params))
    #     PoF_converging.append(calculate_PoF(b, **params))
    #     Pof_weight_converging.append(calculate_PoFweighting(b, **params))
    #     energy_converging.append(calculate_energy(b, **params))
    #     times_converging.append(calculate_times(b, **params))
    #
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_b_converging(b_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_expected_utility_converging(expected_utility_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_pricing_converging(pricing_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_energy_converging(energy_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_time_converging(time_converging, params)
    #
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_PoF_converging(PoF_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_PoF_weight_converging(Pof_weight_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_PoF_and_PoF_weight_converging(PoF_converging, Pof_weight_converging, params)
    # if params["GENERATE_CONVERGING_FIGURES"]: plot_PoF_div_PoF_weight()
    # if params["GENERATE_CONVERGING_FIGURES"]: plot_expected_utility_and_time_energy_pricing_converging(expected_utility_converging, times_converging, energy_converging, pricing_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_b_converging2(b_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_times_converging2(times_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_energy_converging2(energy_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_payment_converging2(pricing_converging, params)
    # # if params["GENERATE_CONVERGING_FIGURES"]: plot_expected_utility_converging2(expected_utility_converging, params)
    # if params["GENERATE_CONVERGING_FIGURES"]: plot_original(b_converging, times_converging, energy_converging, pricing_converging, expected_utility_converging, PoF_converging, params)


    results = {
        "params": params,
        "b": b,
        "expected_utility": expected_utility,
        "iterations": iterations + 1, # add 1 to show the number of iterations
        "pricing": calculate_costs(b, **params),
        "energy": calculate_energy(b, **params),
        "times": calculate_times(b, **params),
        "PoF": calculate_PoF(b, **params),
        "PoFweight": calculate_PoFweighting(b, **params),
        "b_converging": b_converging,
        "expected_utility_converging": expected_utility_converging,
        "pricing_converging": pricing_converging,
        "PoF_converging": PoF_converging,
        "Pof_weight_converging": Pof_weight_converging,
        "energy_converging": energy_converging,
        "times_converging": times_converging,
            }


    return results
