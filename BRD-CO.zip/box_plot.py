import matplotlib.pyplot as plt
import numpy as np

#读取对应数值
Time = []
nrmse.append(value1[0])
nrmse.append(value2[0])
nrmse.append(value3[0])

psnr = []
psnr.append(value1[1])
psnr.append(value2[1])
psnr.append(value3[1])

ssim = []
ssim.append(value1[2])
ssim.append(value2[2])
ssim.append(value3[2])


#画布
figure, axes = plt.subplots(nrows=4, ncols=1, figsize=(12, 12))

bplot1 = axes[0].boxplot(Time, vert=True, patch_artist=True, showmeans=True, meanline=True)
axes[0].set_title('Time', fontsize=15)
bplot2 = axes[1].boxplot(psnr, vert=True, notch=True, patch_artist=True, showmeans=True, meanline=True)
axes[1].set_title('Energy', fontsize=15)
bplot3 = axes[2].boxplot(ssim, vert=True, patch_artist=True, showmeans=True, meanline=True)
axes[2].set_title('Pricing', fontsize=15)
bplot4 = axes[3].boxplot(ssim, vert=True, patch_artist=True, showmeans=True, meanline=True)
axes[3].set_title('Utility', fontsize=15)

#颜色填充
colors = ['pink', 'lightblue', 'lightgreen']
for bplot in (bplot1, bplot2, bplot3):
    for patch, color in zip(bplot['boxes'], colors):
        patch.set_facecolor(color)

#添加刻度
# plt.setp(axes, xticks=[1, 2, 3], xticklabels=['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15'])
figure.savefig('box.png', dpi=figure.dpi)
plt.show()