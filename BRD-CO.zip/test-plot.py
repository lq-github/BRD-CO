import plotly.express as px
df = px.data.iris()
print(type(df))
fig = px.scatter_matrix(df,
    dimensions=["sepal_width", "sepal_length", "petal_width", "petal_length"],
    color="species")
print(type(fig))
fig.show()

# import plotly.express as px
# df = px.data.iris()
# fig = px.scatter_matrix(df)
# fig.show()

# #导入matplotil库，用于画图
# import matplotlib.pyplot as plt
# #导入numpy库，用于数据处理
# import numpy as np
# #画图
# data = np.arange(10)
# plt.plot(data)
# #使图像展示出来
# plt.show()
