'''
Parameters of the simulation

'''


import numpy as np
import dill

def set_parameters(case, N):
    '''
    Sets the parameters used in the simulation
    设置模拟中使用的参数
    Parameters
    ----------

    case: dictionary
        Dictionary containing infromation about whether the user homogeneous or heterogeneous
        字典中包含关于用户是同构还是异构的信息
    N: int
        Number of users 用户数量

    Returns
    ----------

    bn: 1-D array 用户拥有的数据量
        Amount of data a user has
    dn: 1-D array 每个用户的工作难度，需要的CPU周期数
        Cycles each user's job needs
    fn: 1-D array 用户的计算能力
        Computational capability of the user
    gn: 1-D array 本地运行一次CPU周期所花费能耗的系数（论文中的伽马）
        Coefficient denoting the consumed energy per cycle locally
    tn: 1-D array 每个用户本地处理数据的时间
        Time to process the data locally by each user
    en: 1-D array 每个用户本地处理数据的能耗
        Energy to process the data locally by each user
    e1: float 用户卸载收敛时出现错误
        Error for user offloading convergence
    an: 1-D array 前景理论效用参数
        Parameter of prospect theory utility
    kn: 1-D array 玩家对收益与损失的敏感性的权重因素
        Weighting factor that captures sensitivity of players toward losses as compared to gains
    cpar: float 用户花费
        The parameter used to set the cost for users
    bpar: float 用户的初始卸载
        The parameter used to set the initial offloading of users
    c: 1-D array 每一列表示每个用户的定价因素
        Each column repesents the pricing factor for each user
    fixed_transm_rate : float 每卸载1比特的传输速率
        The transmission rate for offloading 1 bit per second [fixed]
    fixed_transm_power : float 传输功率
        The transmission power used for the transmission [fixed]
    '''

    # 保存图片
    SAVE_FIGS = True
    # 一张图片
    ONE_FIGURE = False
    # 生成图片
    GENERATE_FIGURES = True
    # 生成收敛图片
    GENERATE_CONVERGING_FIGURES = True
    # 加载保存的参数
    LOAD_SAVED_PARAMETERS = False
    # 保存参数
    SAVE_PARAMETERS = False
    # 保存结果
    SAVE_RESULTS = True
    # 卸载常量
    CONSTANT_OFFLOADING = False

    e1 = 10000

    # 情况1：用户是同构的
    if case["users"] == "homo":
        # 用户数据量bn(bit)
        bn = 10*1e6 * np.ones(N) + np.random.uniform(-1, 1, size=N) * 1e6
        # 任务的计算难度o（cycles/bit）----------------------------------------------------
        o = 1000
        # 处理用户数据量bn需要的CPU周期(cycles)--------------------------------------------
        dn = bn * o
        # 服务器计算能力(cycles/s)---------------------------------------------------
        fmn = 6e10 * np.ones(N)
        # 服务器运行一次CPU周期所花费能耗的系数(J/cycles)----------------------------------
        gmn = 4e-8 * np.ones(N)
        # 用户的本地计算能力(cycles/s)
        fln = 6e7 * np.ones(N)+ np.random.uniform(-1, 1, size=N) * 1e7
        # 本地运行一次CPU周期所花费能耗的系数(J/cycles)
        gln = 4e-9 * np.ones(N)+ np.random.uniform(-1, 1, size=N) * 1e-9
        # 前景理论效用参数
        an = 0.2 * np.ones(N)
        # 用户对收益与损失的敏感性
        kn = 1.2 * np.ones(N)
    # 情形2：用户是异构的
    elif case["users"] == "hetero":
        # 用户数据量bn(bit)
        bn = 10 * 1e6 * np.ones(N) + np.random.uniform(-1, 1, size=N) * 1e6
        # 任务的计算难度o（cycles/bit）----------------------------------------------------
        o = 1000
        # 处理用户数据量bn需要的CPU周期(cycles)--------------------------------------------
        dn = bn * o
        # 服务器计算能力(cycles/s)---------------------------------------------------
        fmn = 6e8 * np.ones(N)
        # 服务器运行一次CPU周期所花费能耗的系数(J/cycles)----------------------------------
        gmn = 4e-9 * np.ones(N)
        # 用户的本地计算能力(cycles/s)
        fln = 6e7 * np.ones(N)+ np.random.uniform(-1, 1, size=N) * 1e9
        # 本地运行一次CPU周期所花费能耗的系数(J/cycles)
        gln = 4e-8 * np.ones(N)+ np.random.uniform(-1, 1, size=N) * 1e-9
        # 前景理论效用参数
        an = 0.2 * np.ones(N)
        # 用户对收益与损失的敏感性
        kn = 1.2 * np.ones(N)

    else:
        exit()

    # lambda1时间的收益系数
    lambda1 = 0.800
    # lambda2能量的收益系数
    lambda2 = 0.001
    # lambda3花费的收益系数
    lambda3 = 0.199
    # 存活时的权重系数
    gama = 0.61
    # 失败时的权重系数
    kesi2 = 0.69



    # 传输速率
    fixed_transm_rate = 1*1e9
    # 传输功率
    fixed_transm_power = 0.1
    # 用户的初始卸载
    bpar = 0
    # 处理任务的收益（$/bit）每一比特的收益----------------------------------------------
    kexi = 5
    # 价格参数
    cpar = 0.5

    e_l = dn * gln   # 本地计算能量
    t_l = dn / fln     # 本地计算时间
    ttt_m = bn / fixed_transm_rate  # 服务器传输时间
    ete_m = fixed_transm_power * bn / fixed_transm_rate  # 服务器传输能量
    tct_m = dn / fmn  # 计算时间
    ece_m = dn * gmn  # 计算能量
    # 服务器总能量
    e_m = ete_m + ece_m
    # 服务器的总时间
    t_m = ttt_m + tct_m
    A = ((t_l - t_m) * lambda1 + (e_l - e_m) * lambda2) / (lambda3 * tct_m)

    # 服务器处理单价 （$/cycle）
    PM_c = cpar * A
    # 本地定价：计算定价（$/s)---------------------------------------------------
    # PL_c = 1e6
    # 本地定价：能量定价（$/J)---------------------------------------------------
    # PL_e = cpar * 1.5
    # 服务器定价：计算定价（$/s)---------------------------------------------------
    # PM_c = cpar * 3.6 * 1e6
    # 服务器传输能量定价（$/J)---------------------------------------------------
    # PM_te = cpar * 0.75
    # 服务器计算能量定价（$/J)---------------------------------------------------
    # PM_ce = cpar * 3
    # 服务器定价：传输定价（$/s)---------------------------------------------------
    # PM_t = cpar * 1e5



    return locals()

# 加载参数
def load_parameters():
    '''
    Loads the parameters from a file
    从文件里加载参数
    Returns
    ----------

    params: dictionary
        Dictionary with the paramters of the simulation
    '''
    print("Loading parameters")
    infile = "saved_runs/parameters/" + "parameters"

    with open(infile, 'rb') as in_strm:
        params = dill.load(in_strm)

    return params

# 保存参数
def save_parameters(params):
    '''
    Saves the parameters in a file

    Parameters
    ----------

    params: dictionary
        Dictionary with the paramters of the simulation
    '''
    outfile = "saved_runs/parameters/" + "parameters"

    with open(outfile, 'wb') as fp:
        dill.dump(params, fp)
