'''
Helper functions that are used in the simulation
模拟中使用的辅助函数
'''

import numpy as np
from game_functions4 import *

# 初始化用户数量，数据量，卸载系数
def initialize(N, bpar, bn, **params):
    '''
    Initialize the probabilities for the simulation
    初始化模拟的概率
    Parameters
    ----------

    N: int 用户数量
        Number of users

    Returns
    -------

    b: 1-D array  每一列表示用户希望卸载到MEC服务器的数据量
        Each column represents the amount of data a user wants to offload to the MEC server.
    b_old: 1-D array  每一列表示前一轮用户希望卸载到MEC服务器的数据量
        Each column represents the amount of data a user wanted to offload on the previous round
        to the MEC server.
    '''
    bpar = np.random.rand(N)

    b = bpar * bn

    # set b_old different to b so that we don't falsely converge
    # 让b_old与b不同，这样我们就不会错误地收敛
    b_old = 1 * np.ones(N)

    return b, b_old


# MEC服务器处理用户n的卸载数据bn,花费的能量成本和时间成本
def calculate_costs(b, dn, bn, lambda3, PM_c,fmn, gmn, fixed_transm_rate, fixed_transm_power, ** params):
    '''
    Calcuate costs imposed by the MEC server to each user

    Parameters
    ----------

    b: 1-D array 每一列表示用户希望卸载到MEC服务器的数据量
        Each column represents the amount of data a user wants to offload to the MEC server.
    bn: 1-D array 每一列表示用户拥有的数据量
        Each column represents the amount of data a user has.
    dn: 1-D array 每一列表示每个用户完成工作需要的周期
        Each column represents the cycles each user's job needs.
    c: 1-D array 每一列表示每个用户的单位定价
        Each column repesents the pricing factor for each user

    Returns
    -------

    costs: 1-D array 每一列表示使用MEC服务器，每个用户需要的成本
        Each column contains the cost imposed by the MEC server to each user
    '''

    # costs = c * dn * b/bn

    u = b / bn

    tct_m = dn / fmn        # 计算时间
    cpro_m = tct_m * PM_c  # 处理花费

    # 卸载后的总花费
    c_po = u * cpro_m

    # 共花费
    # costs = t_po * lambda1 - c_po * lambda2
    costs = c_po

    # # 本地
    # cc_l = (1-u)*PL_c * dn / fln
    # ce_l = (1-u)*PL_e * dn * gln
    # # 服务器
    # ct_m = u * PM_t * bn / fixed_transm_rate
    # cet_m = u * PM_e * fixed_transm_power * bn / fixed_transm_rate
    # cc_m = u * PM_c * dn / fmn
    # ce_m = u * PM_e * dn * gmn

    # # 本地总花费
    # tc_l = cc_l + ce_l
    # # 服务器总花费
    # tc_m = ct_m + cet_m + cc_m + ce_m
    # # 共花费
    # costs = tc_l + tc_m

    return costs

# 计算MEC服务器的故障概率POF
def calculate_PoF(b, bn, dn, **params):
    '''
    Calculate probability of failure of the MEC server

    Parameters
    ----------

    b: 1-D array 每一列表示用户希望卸载到MEC服务器的数据量
        Each column represents the amount of data a user wants to offload to the MEC server.
    bn: 1-D array 每一列表示用户拥有的数据量
        Each column represents the amount of data a user has.
    dn: 1-D array 每一列表示每个用户完成工作需要的周期
        Each column represents the cycles each user's job needs.

    Returns
    -------

    Pr: float MEC服务器故障的概率
        The probability of failure of the MEC server
    '''

    # dt = 1/(1+np.exp(-1.2e-11*np.sum(dn*b/bn)))
    dt = -1 + 2/(1+np.exp(-2.0e-11*np.sum(dn*b/bn)))
    PoF = dt**2

    return PoF

# 计算故障概率权重
def calculate_PoFweighting(b, gama, kesi2, **params):
    PoF_temp = calculate_PoF(b,**params)
    return PoFWeight(False,PoF_temp,gama,kesi2)


# 根据选择的卸载方式计算每个用户花费的能量
def calculate_energy(b, dn, bn, gln, gmn, lambda2, fixed_transm_rate, fixed_transm_power, **params):
    u = b / bn

    # # 本地
    # ce_l = dn * gln  # 本地计算能量花费
    #
    # # 服务器
    # cte_m = fixed_transm_power * bn / fixed_transm_rate   # 服务器传输能量花费
    # cce_m = dn * gmn    # 计算能量花费
    #
    # # 本地总花费
    # c_l = ce_l
    # # 服务器总花费
    # c_m = cte_m + cce_m
    # # 总能量
    # energy = u * c_m + (1 - u) * c_l

    # 本地
    e_l = dn * gln   # 本地计算能量花费

    # 服务器
    ete_m = fixed_transm_power * bn / fixed_transm_rate   # 服务器传输能量
    ece_m = dn * gmn    # 计算能量

    # 服务器的总能量
    e_m = ete_m + ece_m

    # 卸载后的总能量
    e_po = u * e_m + (1 - u) * e_l

    energy = e_po

    return energy

# 根据选择的卸载方式计算每个用户花费的时间
def calculate_times(b, dn, bn, lambda1, fln, fmn, fixed_transm_rate, ** params):

    u = b / bn

    # 本地计算时间
    t_l = dn / fln

    # 服务器
    ttt_m = bn / fixed_transm_rate    # 服务器传输时间
    tct_m = dn / fmn        # 计算时间

    # 服务器的总时间
    t_m = ttt_m + tct_m

    # 部分卸载的时间
    t_po = np.empty_like(u)
    for i in range(len(u)):
        t_po[i] = max(u[i] * t_m[i], (1 - u[i]) * t_l[i])

    # 总时间
    time = t_po

    # # 卸载后的总时间和总花费
    # # t_po = np.empty_like(u)
    # # for i in range(len(u)):
    #       t_po[i] = max(u[i] * t_m[i], (1 - u[i]) * t_l[i])
    # # 本地
    # cc_l = (1-u)*PL_c * dn / fln
    # ce_l = (1-u)*PL_e * dn * gln
    # # 服务器
    # ct_m = u * PM_t * bn / fixed_transm_rate
    # cet_m = u * PM_e * fixed_transm_power * bn / fixed_transm_rate
    # cc_m = u * PM_c * dn / fmn
    # ce_m = u * PM_e * dn * gmn

    # # 本地总花费
    # tc_l = cc_l + ce_l
    # # 服务器总花费
    # tc_m = ct_m + cet_m + cc_m + ce_m
    # # 共花费
    # costs = tc_l + tc_m

    return time

# 检查所有的参数
def check_all_parameters(bn, dn, an, kn, c, tn, en, **params):

    working = 0
    eps = 10
    for an1 in np.linspace(0.3, 1, 8):
        an = an1

        for kn1 in np.linspace(0.1, 2, 10):
            kn = kn1
            working += 1
            print(working)

            for dn1 in np.linspace(1, 10, 10):
                dn = dn1 * 1e9 * np.ones(params["N"])

                for fn1 in np.linspace(1, 10, 10):
                    fn = fn1 * 1e9 * np.ones(params["N"])
                    tn = dn/fn

                    for gn1 in np.linspace(1, 10, 10):
                        gn = gn1 * 1e-9 * np.ones(params["N"])
                        en = gn * dn

                        for bn1 in np.linspace(1, 10, 10):
                            bn = bn1 * 1e6 * np.ones(params["N"])

                            for c1 in np.linspace(2e-1, 9e-1, 8):
                                c = c1 * bn/dn * (1 - (1/(tn*en)))

                                if c.all() > 0:

                                    counter = 0

                                    for i, value in enumerate(np.linspace(0,bn[0],11)):

                                        b_others = value * np.ones(5)

                                        res = fminbound(utility_function, 0, bn[0], args=(0, b_others, dn, bn, an, kn, c, tn, en), disp=False)
                                        result_utility = -utility_function(res, 0, b_others, dn, bn, an, kn, c, tn, en)

                                        if (res > eps) and (res <  bn[0] - eps) and (np.isfinite(result_utility)):
                                            counter += 1

                                    if counter > 8:
                                        my_string = ("Counter: " + str(counter) + "\n" +
                                            "an: " + str(an) +
                                            " kn: " + str(kn) +
                                            " bn: " + str(bn1) +
                                            " dn: " + str(dn1) +
                                            " fn: " + str(fn1) +
                                            " gn: " + str(gn1) +
                                            " c: " + str(c1) + "\n")

                                        with open('result.txt' , 'a') as writer:
                                            writer.write(my_string)

    return "Done"

# 检查最好的参数
def check_best_parameters(bn, dn, an, kn, c, tn, en, **params):

    N = 10000

    fig, ax = plt.subplots(11,1)
    plt.suptitle("an: " + str(an) +
            " bn: " + str(bn[0]) +
            " dn: " + str(dn[0]) +
            " kn: " + str(kn) +
            " tn: " + str(tn[0]) +
            " en: " + str(en[0]) +
            " c: " + str(c[0]), fontsize=6)

    for i, value in enumerate(np.linspace(0,bn[0],11)):

        b_others = value * np.ones(params["N"])

        eps = 0.2
        res = fminbound(utility_function, 0, bn[0], args=(0, b_others, dn, bn, an, kn, c, tn, en), disp=False)
        result_utility = -utility_function(res, 0, b_others, dn, bn, an, kn, c, tn, en)

        if (res > eps) and (res <  bn[0] - eps) and (np.isfinite(result_utility)):
            print()
            print(res)
            print(result_utility)

        x = np.linspace(0, bn[0], N)
        res = np.empty_like(x)
        for j in range(len(x)):
            res[j] = -utility_function(x[j], 0, b_others, dn, bn, an, kn, c, tn, en)


        plt.subplot(11,1,i+1)
        print(x[-1])
        plt.text(x[-1], res[-1], "others = " + str(value), fontsize=8)
        plt.plot(x, res)

    plt.xlabel('bnMEC', fontweight='normal')

    plt.show()

    return "Done"
