import math
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import host_subplot
colors = ['mediumpurple', 'gold', 'mediumseagreen', 'cornflowerblue', 'orange', 'hotpink']
line_types = ['v-', '*-', 'o-', 'p-', 'D-', 'd-']


plt.rc('font', family='serif')
plt.rc('font', size=32)
plt.rc('xtick', labelsize='x-small')
plt.rc('ytick', labelsize='x-small')

# host.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

plt.figure(figsize=(16, 6))
grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

axes1 = plt.subplot(grid[0, 0])
# axes1 = fig.add_subplot(2, 2, 1)
# 加粗边框
bwith = 2
ax = plt.gca()  # 获取边框
ax.spines['bottom'].set_linewidth(bwith)
ax.spines['left'].set_linewidth(bwith)
ax.spines['top'].set_linewidth(bwith)
ax.spines['right'].set_linewidth(bwith)

x = np.linspace(0.001,0.9,20)

#设置图形宽度
bar_width = 0.2
X_R = np.arange(len(x))  # R条形图的横坐标
X_F = X_R + bar_width  # F条形图的横坐标
X_L = X_R + bar_width*2
X_G = X_R + bar_width*3
X_L_MOODO = X_R + bar_width*4
X_F_MOODO = X_R + bar_width*5

axes1.set_title('(a)', y=-0.3, fontsize='small')

axes1.set_ylabel('Utility')
axes1.set_xlabel('ω')
# axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
#
# axes1.set_xticks(X_R)
# # axes1.set_xticklabels(np.linspace(0.1,1,5))
# axes1.set_xticklabels(x,rotation=45)

RM_OCO = np.array([0.262534711,0.263799693,0.265008736,0.265792956,0.266281275,
                   0.266549027,0.266643931,0.266598052,0.266433871,0.266167678,
                   0.265811558,0.265374626,0.264863836,0.264284524,0.263640777,
                   0.262935687,0.262171549,0.261350001,0.260472109,0.259538605])
F_MOODO = np.array([0.261905566,0.263835547,0.26507234,0.265876116,0.266378885,
           0.26665774,0.266761423,0.267621628,0.267461022,0.267197374,
           0.266842938,0.266406975,0.265896559,0.265317082,0.264672695,
           0.263966547,0.263201005,0.262377938,0.261498188,0.260562334])
L = np.zeros(20)+0.01
F = np.array([-1.398703573,-1.508269501,-1.59620703,-1.670336096,-1.734801186,
     -1.792085244,-1.84380249,-1.894387852,-1.938258261,-1.979045829,
     -2.017216632,-2.053136525,-2.087098407,-2.119340751,-2.150060562,
     -2.179422672,-2.207566559,-2.234611448,-2.260660184,-2.285802229])
G = np.array([0.231069918,0.229420714,0.228333446,0.226646134,0.225043587,
     0.223584827,0.22224305,0.211557689,0.209922353,0.208338621,
     0.206797266,0.205291535,0.203816924,0.202371146,0.200954961,
     0.19957555,0.198224278,0.196541037,0.194855088,0.193163566])
R = np.array([-0.190679003,-0.266418646,-0.319362337,-0.358669098,-0.405034591,
     -0.444793508,-0.471663264,-0.491071045,-0.520378183,-0.543414683,
     -0.568475971,-0.59985494,-0.620521097,-0.633590892,-0.655885367,
     -0.676267283,-0.706866005,-0.705533716,-0.736497284,-0.744900983])

# line1 = axes1.bar(X_F, F, width=bar_width, align='center',label="F. Offl.",color=colors[0])
# line2 = axes1.bar(X_R, R, width=bar_width, align='center',label="R. Offl.",color=colors[1])
# line3 = axes1.bar(X_L, L, width=bar_width, align='center',label="L. Offl.",color=colors[2])
# line4 = axes1.bar(X_G, G, width=bar_width, align='center',label="G. Offl.",color=colors[3])
# line5 = axes1.bar(X_L_MOODO, L_MOODO,width=bar_width, align='center', label="L-MOODO",color=colors[4])
# line6, = axes1.bar(X_F_MOODO, F_MOODO,width=bar_width, align='center', color=colors[5])

line1, = axes1.plot(x, F, line_types[0], lw=2, label="R. Offl.",color=colors[0])
line2, = axes1.plot(x, R, line_types[1], lw=2, label="F. Offl.",color=colors[1])
line3, = axes1.plot(x, L, line_types[2], lw=2, label="L. Offl.",color=colors[2])
line4, = axes1.plot(x, G, line_types[3], lw=2, label="G. Offl.",color=colors[3])
line5, = axes1.plot(x, RM_OCO, line_types[4], lw=2, label="RM-OCO",color=colors[4])
# line6, = axes1.plot(x, F_MOODO, line_types[5], lw=4, label="M-MOODO",color=colors[5])

# plt.legend(handles=[grey_lines, black_line], loc=1, prop={'size': 24})
plt.legend(loc=3, prop={'size': 12},ncol=1)

# 子图2
# axes2 = fig.add_subplot(3, 3, 3)
axes2 = plt.subplot(grid[0, 1])
ax = plt.gca()  # 获取边框
ax.spines['bottom'].set_linewidth(bwith)
ax.spines['left'].set_linewidth(bwith)
ax.spines['top'].set_linewidth(bwith)
ax.spines['right'].set_linewidth(bwith)
axes2.set_title('(b)', y=-0.3, fontsize='medium')
axes2.set_xlabel('PoF')
axes2.set_ylabel('Decision Weight')
# axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
Pr = np.arange(0, 1, 0.01)
Decision_Weight = Pr ** 0.61 / (Pr ** 0.61 + (1 - Pr) ** 0.61) ** (1 / 0.61)
line2, = axes2.plot(Pr, Decision_Weight, line_types[0], lw=4, label="offloaded data",
                    color=colors[1])
axes2.plot(Pr, Pr, line_types[1], lw=4, label="offloaded data",
           color=colors[1])
path_name = "comparion_method1"

# plt.legend(handles=[grey_lines, black_line], loc=1, prop={'size': 24})
# axes1.legend(loc=1, prop={'size': 16})


plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
plt.savefig("plots/" + path_name + ".png", bbox_inches='tight', dpi=600, pad_inches=0.1)
