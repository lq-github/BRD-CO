import numpy as np
np_list1 = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]).reshape((4,3))
print(np_list1)
aaa = np.mean(np_list1,axis=0)
# bpar = np.linspace(0.001,0.9,20)
bpar = np.linspace(0.001,0.9,20)
print(aaa)
print(bpar)
# a=[1,2]
# b=[4,5,6]
# print(np.hstack((a,b)))
# c = np.ones(25)
# print(c)
# list1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
# print(map(str, list1))
# print(type(map(str, list1)))
# str111 = ','.join(map(str, list1))
# print(str111)
# for i in list1:
#     list2.append(int(i))
# print(list2)
# list1 = ["123","qwe","你好","liu"]
# str1 = "and,".join(["123456789"])
# print(str1)



# for i in list1:
#     print(i)
# aaa = [i+"刘琦" for i in list1 if i=="qwe"]
# print(aaa)
# f1 = open("www.txt","w")
# f1.write("nihao,你好，123")
# f1.close()
#
# with open("outfile" + ".csv", "w") as fp_compare:
#     fp_compare.write(list_name + "\n")
# print()


# import matplotlib.pyplot as plt
#
# plt.rc('font', family='serif')
# plt.rc('font', size=32)
# plt.rc('xtick', labelsize='x-small')
# plt.rc('ytick', labelsize='x-small')
# plt.figure(figsize=(8, 6))
# # grid = plt.GridSpec(1, 1, wspace=0.3, hspace=0.3)
# grid = plt.GridSpec(1, 1)
# axes1 = plt.subplot(grid[0, 0])
# # axes1 = fig.add_subplot(2, 2, 1)
# # 加粗边框
# bwith = 2
# ax = plt.gca()  # 获取边框
# ax.spines['bottom'].set_linewidth(bwith)
# ax.spines['left'].set_linewidth(bwith)
# ax.spines['top'].set_linewidth(bwith)
# ax.spines['right'].set_linewidth(bwith)
#
# Ns = [1, 2, 5, 15, 25, 35, 45, 55, 65, 75, 85, 95, 100]
# payment_factor = [0.001, 0.001, 0.23758, 0.28489, 0.33221, 0.33221, 0.33221, 0.33221, 0.37953, 0.37953, 0.37953,
#                   0.37953, 0.37953]
# axes1.plot(Ns, payment_factor, lw=4, color="royalblue")
# axes1.set_xlabel('Number of users')
# axes1.set_ylabel('ω')
# path_name = "N_and_payment"
# plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

# import numpy as np
# cs = np.linspace(0.001,0.9,20)
# print(cs)
import time
# import numpy as np
# import matplotlib.pyplot as plt
#
#
# aaa = np.array([[1,2,5,3,4],[3,2,7,3,8],[5,2,8,3,6]])
# bbb = np.array([5,8,6])
# plt.figure()
# plt.plot(aaa[1])
# plt.plot(bbb)
# # plt.boxplot(aaa, boxprops={'facecolor': 'white'}, vert=True, patch_artist=True, showmeans=True, meanline=True,)
# plt.show()
# # time.sleep(1000)


# import matplotlib.pyplot as plt
# plt.figure(figsize=(4,3))
# grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)
# ax = plt.subplot(grid[0, 0])
# # host = host_subplot(111, axes_class=AA.Axes)
#
# ax.set_xlabel('$\\alpha _{p{d_i}}}$')
# plt.savefig("plots/" + "1111111" + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
#


import numpy as np
#
# x = np.linspace(-1, 1, 50)  # 从(-1,1)均匀取50个点
# y = 2 * x
#
# plt.plot(x, y)
# plt.show()


# import math
# import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.axes_grid1 import host_subplot
#
# line_types = ['-', '--']
# colors = ["royalblue", "k"]
#
# plt.rc('font', family='serif')
# plt.rc('font', size=32)
# plt.rc('xtick', labelsize='x-small')
# plt.rc('ytick', labelsize='x-small')
#
# # host.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)
#
# plt.figure(figsize=(16, 6))
# grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)
#
# axes1 = plt.subplot(grid[0, 0])
# # axes1 = fig.add_subplot(2, 2, 1)
# # 加粗边框
# bwith = 2
# ax = plt.gca()  # 获取边框
# ax.spines['bottom'].set_linewidth(bwith)
# ax.spines['left'].set_linewidth(bwith)
# ax.spines['top'].set_linewidth(bwith)
# ax.spines['right'].set_linewidth(bwith)
# axes1.set_title('(a)', y=-0.3, fontsize='small')
# axes1.set_xlabel('Average Offloaded Data ')
# axes1.set_ylabel('PoF')
# # axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
# x = np.arange(0, 12, 0.05)
# Pr = (-1 + 2 / (1 + np.exp(-x))) ** 2
# line1, = axes1.plot(x, Pr, line_types[0], lw=4, label="Probability_of_Failure",
#                     color=colors[0])
# # axes1.legend(loc=1, prop={'size': 24})
#
# # 子图2
# # axes2 = fig.add_subplot(3, 3, 3)
# axes2 = plt.subplot(grid[0, 1])
# ax = plt.gca()  # 获取边框
# ax.spines['bottom'].set_linewidth(bwith)
# ax.spines['left'].set_linewidth(bwith)
# ax.spines['top'].set_linewidth(bwith)
# ax.spines['right'].set_linewidth(bwith)
# axes2.set_title('(b)', y=-0.3, fontsize='medium')
# axes2.set_xlabel('PoF')
# axes2.set_ylabel('Decision Weight')
# # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
# Pr = np.arange(0, 1, 0.01)
# Decision_Weight = Pr ** 0.61 / (Pr ** 0.61 + (1 - Pr) ** 0.61) ** (1 / 0.61)
# line2, = axes2.plot(Pr, Decision_Weight, line_types[0], lw=4, label="offloaded data",
#                     color=colors[1])
# axes2.plot(Pr, Pr, line_types[1], lw=4, label="offloaded data",
#            color=colors[1])
# path_name = "PoF_div_Pof_weight"
# plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
# plt.savefig("plots/" + path_name + ".png", bbox_inches='tight', dpi=600, pad_inches=0.1)

#
# import random
# import numpy as np
# # Ns = random.sample(range(0,150),20)
# Ns = np.arange((1000)).reshape((5,2,10,10))
# print(Ns)


# import math
# import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.axes_grid1 import host_subplot
# def plot_PoF_div_Pof_weight():
#     plt.figure(figsize=(16, 6))
#     grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)
#
#     axes1 = plt.subplot(grid[0, 0])
#     axes1.set_xlabel('Average Offloaded Data ')
#     axes1.set_ylabel('Probability of Failure')
#     x = np.arange(0, 10, 1)
#
#     Pr = (-1 + 2 / (1 + np.exp(-x))) ** 2
#     # x = np.arange(-10, 0, 0.1)
#     # Pr = 1 / x
#     line1, = axes1.plot(x, Pr, '-', lw=4, label="Probability_of_Failure",
#                         color='k')
#     path_name = "pr"
#     plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
#
# plot_PoF_div_Pof_weight()


# import numpy as np
# aaa = np.array([0,1,5,23,5,985,65])
# bbb = np.array([3,5,6,25,5,8,5])
# ccc = np.maximum(aaa,bbb)
# print(aaa)
# print(bbb)
# print(ccc)
#
# aaa = 1.0254500154541
# print(type(aaa))
# print(id(aaa))
# bbb = aaa.copy()
# print(bbb)
# print(id(bbb))
# bbb = 158164354.212
# print(bbb)
# print(id(bbb))

# aaa = np.arange(15)
# # print(aaa)
# print(id(aaa))
# bbb = aaa.copy()
# print(id(bbb))
# bbb[2] = 100
# print(bbb)
# print(aaa)
# 画四维图





# import numpy as np
#
# a = np.array([0,0,0,0,0,0])
#
# def test1(a,i):
#     aaa = 1
#     bbb = 2
#     a[i] = i+5
#     # return aaa, bbb
#     return -aaa,-bbb
#
# ccc,ddd = test1(a,3)
# print(a)
# print(ccc)
# print(ddd)




#
# import numpy as np
# import math
# np.set_printoptions(suppress=True)
# rs = np.linspace(0.00001,0.1,20)
# print(rs)

# c = [-336046762.1977215]
# cc = np.array(c)
#
# dd = cc[0]
# dd = [dd]
# dd = np.float(dd[0])
# aaa = pow(dd, 0.87)


# is_surv = False
# gama = 0.61
# kesi2 = 0.69
# a = gama if is_surv else kesi2
# print(a)

import numpy as np
#
# import ceshi1
# tempp = ceshi1.para()
# print(tempp)
# tempp["u"] = np.ones(24)*3
# print(tempp["aaa"])
# print(tempp["u"])
# print(tempp["bbb"])
# print(tempp['aaa']*tempp["u"])
#
# # b = 1
# if b == 1:
#     a = 1
# else:
#     a = 3
# bpars = [-1, 0, 0.5, 1] if False else [-1]
# print( ["11","141"] if b == 1 else ["111"])
# print(a)

# N = 25
# aaa = 0.2 *np.ones(N)
# print(aaa)

# from scipy.optimize import fminbound
# c = 3
# b = 2
# f = lambda x, b, c: x**2 -b*x + c
#
# aa,bb,cc,dd= fminbound(f, -2, 13, args=(b,c), disp=False, full_output=True)
# print(aa)
# print(bb)
# print(cc)
# print(dd)

# N = 25
# bn = 10 * 1e6 * np.ones(N) + np.random.uniform(-1, 1, size=N) * 1e6
# cn = [bn.copy()]
# print(type(bn))
# print(cn)
# print(type(cn))
# print(len(cn))


#
# def aaa(i,ii,p1,p2,p3,**params):
#     print(type(params))
#     print(params)
#     print(p1)
#     print(p2)
#     print(p3)
#
# dict1 = {"p1":"这是p1", "p2":"这是p2", "p3":"这是p3"}
# aaa(1,4,**dict1)

# for i in range(0,0+1):
#     print(i)

# c = [1,1,2,3,4,5,6]
# print(c.pop())

# b = 10*1e6
# print(b)
# print(1e7)

# N=25
# a = np.random.uniform(-1, 1, size=N) * 1e6
# print(a)
# cs = np.linspace(1,10,10)
# print(cs)


# def aaa():
#     a = 1
#     b = 2
#     return locals()
#
# print(type(aaa()))
# print(aaa())