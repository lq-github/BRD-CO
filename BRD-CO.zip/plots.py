'''
Plot functions to graphically present simulation results
'''

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA
import math


def setup_plots(suptitle):

    '''
    Basic setup of plots so it can be reused on plot functions

    Parameters
    ----------

    suptitle: string
        Description of the plot that will appear on the top

    Returns
    -------

    Figure and axis matplotlib structs

    '''
    plt.rc('font', family='serif')
    plt.rc('font', size=44)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

    fig, ax = plt.subplots(1, 1, figsize=(16, 12))
    # fig.suptitle(suptitle)
    # for item in ([ax.title, ax.xaxis.label, ax.yaxis.label]):
    #     item.set_fontsize(30)
    # for item in (ax.get_xticklabels() + ax.get_yticklabels()):
    #     item.set_fontsize(26)
    #     item.set_fontweight("normal")
    # font = {'weight' : 'normal'}
    # matplotlib.rc('font', **font)

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    # Provide tick lines across the plot to help viewers trace along
    # the axis ticks.
    plt.grid(True, 'major', 'y', ls='--', lw=.5, c='k', alpha=.3)

    # Remove the tick marks; they are unnecessary with the tick lines we just
    # plotted.
    plt.tick_params(axis='both', which='both', bottom=True, top=False,
    labelbottom=True, left=False, right=False, labelleft=True)

    return fig, ax

def plot_b_converging(b_converging, params):
    '''
    Plot the data each user is trying to offload till convergence

    Parameters
    ----------

    b_converging: 2-d array
        Contains on each row the amount of data each user is trying to offload. Each row is
        a different iteration

    Returns
    -------

    Plot

    '''
    # (25,15) 第一个全是0
    result = b_converging

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    # 转置->(15,25)
    result = np.transpose(result)

    suptitle = "Data each user is trying to offload in each iteration"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    for index, row in enumerate(result):
        # # display only some of the users on the plot
        # if index%11 == 0:
        #     line = plt.plot(row, lw=4)
        line = plt.plot(row, '-', lw=2, color='0.5')

    average = np.mean(result, axis=0)
    line = plt.plot(average, '-', lw=4, color='black')

    plt.xlabel('iterations', fontweight='normal')
    plt.ylabel('Amount of Offloaded Data [bits]', fontweight='normal')

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

    grey_lines = mlines.Line2D([], [], lw = 2, color='0.5', label='each user')
    black_line = mlines.Line2D([], [], lw = 4, color='k', label='average')
    plt.legend(handles=[grey_lines, black_line], loc=1, prop={'size': 24})

    path_name = "b_converging"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".png")
    else:
        plt.show(block=False)

def plot_expected_utility_converging(expected_utility_converging, params):
    '''
    Plot the expected utility of each user till convergence

    Parameters
    ----------

    expected_utility_converging: 2-d array
        Contains on each row the expected utility of each user. Each row is
        a different iteration

    Returns
    -------

    Plot

    '''
    result = expected_utility_converging

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    result = np.transpose(result)

    suptitle = "Expected utility of each user in each iteration"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    for index, row in enumerate(result):
        # # display only some of the users on the plot
        # if index%11 == 0:
        #     line = plt.plot(row, lw=4)
        line = plt.plot(row, '-', lw=2, color='0.5')

    average = np.mean(result, axis=0)
    line = plt.plot(average, '-', lw=4, color='k')

    plt.xlabel('iterations', fontweight='normal')
    plt.ylabel("User's Expected Utility", fontweight='normal')

    grey_lines = mlines.Line2D([], [], lw = 2, color='0.5', label='each user')
    black_line = mlines.Line2D([], [], lw = 4, color='k', label='average')
    plt.legend(handles=[grey_lines, black_line], loc=1, prop={'size': 24})

    path_name = "expected_utility"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".png")
    else:
        plt.show(block=False)

def plot_pricing_converging(pricing_converging, params):
    '''
    Plot the pricing set for each user till convergence

    Parameters
    ----------

    pricing_converging: 2-d array
        Contains on each row the pricing for each user. Each row is
        a different iteration

    Returns
    -------

    Plot

    '''
    result = pricing_converging

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    result = np.transpose(result)

    suptitle = "Pricing each user in each iteration"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

    for index, row in enumerate(result):
        # # display only some of the users on the plot
        # if index%11 == 0:
        #     line = plt.plot(row, lw=4)
        line = plt.plot(row, '-', lw=2, color='0.5')

    average = np.mean(result, axis=0)
    line = plt.plot(average, '-', lw=4, color='k')

    plt.xlabel('iterations', fontweight='normal')
    plt.ylabel('Pricing', fontweight='normal')

    grey_lines = mlines.Line2D([], [], lw = 2, color='0.5', label='each user')
    black_line = mlines.Line2D([], [], lw = 4, color='k', label='average')
    plt.legend(handles=[grey_lines, black_line], loc=1, prop={'size': 24})

    path_name = "pricing"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".png")
    else:
        plt.show(block=False)

def plot_energy_converging(energy_converging, params):
    '''
    Plot the energy set for each user till convergence

    Parameters
    ----------

    pricing_converging: 2-d array
        Contains on each row the energy for each user. Each row is
        a different iteration

    Returns
    -------

    Plot

    '''
    result = energy_converging

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    result = np.transpose(result)

    suptitle = "energy each user in each iteration"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

    for index, row in enumerate(result):
        # # display only some of the users on the plot
        # if index%11 == 0:
        #     line = plt.plot(row, lw=4)
        line = plt.plot(row, '-', lw=2, color='0.5')

    average = np.mean(result, axis=0)
    line = plt.plot(average, '-', lw=4, color='k')

    plt.xlabel('iterations', fontweight='normal')
    plt.ylabel('energy', fontweight='normal')

    grey_lines = mlines.Line2D([], [], lw = 2, color='0.5', label='each user')
    black_line = mlines.Line2D([], [], lw = 4, color='k', label='average')
    plt.legend(handles=[grey_lines, black_line], loc=1, prop={'size': 24})

    path_name = "energy"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".png")
    else:
        plt.show(block=False)

def plot_time_converging(time_converging, params):
    '''
    Plot the time set for each user till convergence

    Parameters
    ----------

    time_converging: 2-d array
        Contains on each row the time for each user. Each row is
        a different iteration

    Returns
    -------

    Plot

    '''
    result = time_converging

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    result = np.transpose(result)

    suptitle = "time each user in each iteration"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

    for index, row in enumerate(result):
        # # display only some of the users on the plot
        # if index%11 == 0:
        #     line = plt.plot(row, lw=4)
        line = plt.plot(row, '-', lw=2, color='0.5')

    average = np.mean(result, axis=0)
    line = plt.plot(average, '-', lw=4, color='k')

    plt.xlabel('iterations', fontweight='normal')
    plt.ylabel('time', fontweight='normal')

    grey_lines = mlines.Line2D([], [], lw = 2, color='0.5', label='each user')
    black_line = mlines.Line2D([], [], lw = 4, color='k', label='average')
    plt.legend(handles=[grey_lines, black_line], loc=1, prop={'size': 24})

    path_name = "time"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".png")
    else:
        plt.show(block=False)

def plot_PoF_converging(PoF_converging, params):
    '''
    Plot the probability of failure of MEC server till convergence

    Parameters
    ----------

    PoF_converging: 1-d array
        Contains the probability of failure of the MEC server in each iteration

    Returns
    -------

    Plot

    '''
    result = PoF_converging

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    result = np.transpose(result)

    suptitle = "Probability of failure of MEC server in each iteration"

    # 画布
    if params["ONE_FIGURE"] == False:
        # fig, ax = setup_plots(suptitle)
        plt.rc('font', family='serif')
        plt.rc('font', size=38)
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')
        plt.figure(figsize=(16, 12))

        # fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(16, 12))
        # fig.suptitle(suptitle)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    # if params["ONE_FIGURE"] == False:
    #     fig, ax = setup_plots(suptitle)
    #
    # # 加粗边框
    # bwith = 2
    # ax = plt.gca()  # 获取边框
    # ax.spines['bottom'].set_linewidth(bwith)
    # ax.spines['left'].set_linewidth(bwith)
    # ax.spines['top'].set_linewidth(bwith)
    # ax.spines['right'].set_linewidth(bwith)

    line = plt.plot(result, '-.', lw=4, color='hotpink')

    plt.xlabel('iterations', fontweight='normal')
    plt.ylabel('PoF', fontweight='normal')

    path_name = "PoF"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_PoF_weight_converging(Pof_weight_converging, params):
    '''
    Plot the probability of failure of MEC server till convergence

    Parameters
    ----------

    PoF_converging: 1-d array
        Contains the probability of failure of the MEC server in each iteration

    Returns
    -------

    Plot

    '''
    result = Pof_weight_converging

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    result = np.transpose(result)

    suptitle = "Probability of failure of MEC server in each iteration"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    line = plt.plot(result, '--', lw=4, color='k')

    plt.xlabel('iterations', fontweight='normal')
    plt.ylabel('PoFweight', fontweight='normal')

    path_name = "PoFweight"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_PoF_and_PoF_weight_converging(PoF_converging, Pof_weight_converging, params):
    '''
    Plot the probability of failure of MEC server till convergence

    Parameters
    ----------

    PoF_converging: 1-d array
        Contains the probability of failure of the MEC server in each iteration

    Returns
    -------

    Plot

    '''
    colors = ['mediumseagreen', 'orange']
    line_types = ['-', '-.']

    # 画布
    if params["ONE_FIGURE"] == False:
        # fig, ax = setup_plots(suptitle)
        plt.rc('font', family='serif')
        plt.rc('font', size=38)
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')

        plt.figure(figsize=(16, 12))


    host = host_subplot(111, axes_class=AA.Axes)
    plt.subplots_adjust(right=0.85)


    ax2 = host.twinx()  # instantiate a second axes that shares the same x-axis
    ax2.axis["right"].toggle(all=True)

    host.set_xlabel('iterations', fontweight='normal')
    host.set_ylabel('PoF', fontweight='normal')
    ax2.set_ylabel('Decision Weight', fontweight='normal')


    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    result1 = PoF_converging
    result2 = Pof_weight_converging

    result1 = np.transpose(result1)
    result2 = np.transpose(result2)

    line1, = host.plot(result1, line_types[0], lw=4, color=colors[0], label='PoF')

    line2, = ax2.plot(result2, line_types[1], lw=4, color=colors[1], label="Decision Weight")

    # host.axis["left"].label.set_color(line1.get_color())
    # ax2.axis["right"].label.set_color(line2.get_color())

    host.legend(loc=1, prop={'size': 20})

    path_name = "PoF and Pof Weight"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_PoF_div_PoF_weight():

    line_types = ['-', '--']
    colors = ["royalblue", "k"]

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')

    # host.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

    plt.figure(figsize=(16, 6))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])
    # axes1 = fig.add_subplot(2, 2, 1)
    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.3, fontsize='small')
    axes1.set_xlabel('Average Offloaded Data')
    axes1.set_ylabel('Pr')
    # axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    x = np.arange(0, 12, 0.05)
    Pr = (-1 + 2 / (1 + np.exp(-x))) ** 2
    line1, = axes1.plot(x, Pr, line_types[0], lw=4, label="Probability_of_Failure",
                        color=colors[0])
    # axes1.legend(loc=1, prop={'size': 24})

    # 子图2
    # axes2 = fig.add_subplot(3, 3, 3)
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.3, fontsize='small')
    axes2.set_xlabel('Pr')
    axes2.set_ylabel('π(Pr)')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    Pr = np.arange(0, 1, 0.01)
    Decision_Weight = Pr ** 0.61 / (Pr ** 0.61 + (1 - Pr) ** 0.61) ** (1 / 0.61)
    axes2.plot(Pr, Decision_Weight, line_types[0], lw=4, label="offloaded data",
                        color=colors[1])
    axes2.plot(Pr, Pr, line_types[1], lw=4, label="offloaded data",
               color=colors[1])
    path_name = "PoF_div_Pof_weight"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    plt.savefig("plots/" + path_name + ".png", bbox_inches='tight', dpi=600, pad_inches=0.1)

    # host.set_xlabel('γ')
    # host.set_ylabel('Average Offloaded Data')
    # par1.set_ylabel('Probability of Failure')

def plot_expected_utility_and_pricing_converging(expected_utility_converging, pricing_converging, params):
    '''
    Plot the average explitic utility and pricing of users till convergence

    Parameters
    ----------

    expected_utility_converging: 2-d array
        Contains on each row the expected utility of each user. Each row is
        a different iteration
    pricing_converging: 2-d array
        Contains on each row the pricing for each user. Each row is
        a different iteration

    Returns
    -------

    Plot

    '''
    # colors = ['k', '0.5']
    # line_types = ['--', ':']

    colors = ['mediumseagreen', 'orange']
    line_types = ['-', '-.']

    result1 = expected_utility_converging
    result2 = pricing_converging

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    result1 = np.transpose(result1)
    result2 = np.transpose(result2)

    suptitle = "Average expected utility and expected pricing for each user in each iteration"

    if params["ONE_FIGURE"] == False:
        plt.rc('font', family='serif')
        plt.rc('font', size=38)
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')
        plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

        fig = plt.figure(figsize=(16,12))

    host = host_subplot(111, axes_class=AA.Axes)
    plt.subplots_adjust(right=0.85)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    ax2 = host.twinx() # instantiate a second axes that shares the same x-axis
    ax2.axis["right"].toggle(all=True)
    ax2.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

    average1 = np.mean(result1, axis=0)

    line1, = host.plot(average1, line_types[0], lw=4, color=colors[0], label='expected utility')

    host.set_xlabel('iterations', fontweight='normal')
    host.set_ylabel('Average Expected Utility', fontweight='normal')

    ax2.set_ylabel('Average Pricing', fontweight='normal')

    average2 = np.mean(result2, axis=0)
    line2, = ax2.plot(average2, line_types[1], lw=4, color=colors[1], label="pricing")

    # host.axis["left"].label.set_color(line1.get_color())
    # ax2.axis["right"].label.set_color(line2.get_color())

    host.legend(loc=1, prop={'size': 20})

    path_name = "expected_utility_and_pricing"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_expected_utility_and_time_energy_pricing_converging(expected_utility_converging, times_converging, energy_converging, pricing_converging, params):
    colors = ['gold', 'mediumseagreen', 'cornflowerblue', 'orange']
    line_types = ['-',  '--', ':', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 12))
    # grid = plt.GridSpec(2, 2, wspace=0.3, hspace=0.3)
    grid = plt.GridSpec(2, 2, wspace=0.3, hspace=0.4)


    # fig = plt.figure(num=5, figsize=(24, 18), dpi=80)
    axes1 = plt.subplot(grid[0, 0])
    # axes1 = fig.add_subplot(2, 2, 1)
    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.33, fontsize='small')
    axes1.set_xlabel('Iteration')
    axes1.set_ylabel('Average Utility')
    # axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result1 = expected_utility_converging
    result1 = np.transpose(result1)
    expected_utility_converging = np.mean(result1, axis=0)
    line1, = axes1.plot(expected_utility_converging, line_types[0], lw=4, label="expected utility", color=colors[0])

    # 子图3
    # axes3 = fig.add_subplot(3, 3, 6)
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.33, fontsize='small')
    axes2.set_xlabel('Iteration')
    axes2.set_ylabel('Average Delay')
    axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = times_converging
    result2 = np.transpose(result2)
    times_converging = np.mean(result2, axis=0)
    line2, = axes2.plot(times_converging, line_types[1], lw=4, label="time", color=colors[1])

   # 子图4
   #  axes4 = fig.add_subplot(3, 3, 7)
    axes3 = plt.subplot(grid[1, 0])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes3.set_title('(c)', y=-0.33, fontsize='small')
    axes3.set_xlabel('Iteration')
    axes3.set_ylabel('Average Energy'+'\n'+'Consumption')
    axes3.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = energy_converging
    result3 = np.transpose(result3)
    energy_converging = np.mean(result3, axis=0)
    line3, = axes3.plot(energy_converging, line_types[2], lw=4, markersize=8, label="energy", color=colors[2])

    # 子图5
    # axes5 = fig.add_subplot(3, 3, 8)
    axes4 = plt.subplot(grid[1, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes4.set_title('(d)', y=-0.33, fontsize='small')
    axes4.set_xlabel('Iteration')
    axes4.set_ylabel('Average Payment')
    axes4.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result4 = pricing_converging
    result4 = np.transpose(result4)
    pricing_converging = np.mean(result4, axis=0)
    line5, = axes4.plot(pricing_converging, line_types[3], lw=4, label="pricing", color=colors[3])

    path_name = "iterations_E_T_E_P"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    plt.savefig("plots/" + path_name + ".png", bbox_inches='tight', dpi=600, pad_inches=0.1)


def plot_b_converging2(b_converging, params):
    # 传进来参数
    Offloadingdata = b_converging

    # 画布
    if params["ONE_FIGURE"] == False:
        # fig, ax = setup_plots(suptitle)
        plt.rc('font', family='serif')
        plt.rc('font', size=38)
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')

        fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(16, 12))
        # fig.suptitle(suptitle)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    # plt.xlabel('iterations', fontweight='normal')
    # plt.ylabel('time', fontweight='normal')

    axes.boxplot(Offloadingdata, boxprops={'facecolor': 'mediumpurple'}, vert=True, patch_artist=True,
                 showmeans=True,
                 meanline=True,
                 meanprops = {'marker':'D','markerfacecolor':'k'},  # 设置均值点的属性，点的形状、填充色
                 medianprops = {'linestyle':'-','color':'red'})  # 设置中位数线的属性，线的类型和颜色 )
    axes.yaxis.grid(True)  # 加水平网格线
    axes.set_ylabel('The Amount of Offloaded Data')# 设置y轴名称
    axes.set_xlabel('iteration')  # 设置x轴名称

    path_name = "b_box"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_times_converging2(times_converging, params):
    # 传进来参数
    Time = times_converging

    # 画布
    if params["ONE_FIGURE"] == False:
        # fig, ax = setup_plots(suptitle)
        plt.rc('font', family='serif')
        plt.rc('font', size=38)
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')


        fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(16, 12))
        # fig.suptitle(suptitle)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    # plt.xlabel('iterations', fontweight='normal')
    # plt.ylabel('time', fontweight='normal')

    axes.boxplot(Time, boxprops={'facecolor': 'cornflowerblue'}, vert=True, patch_artist=True, showmeans=True,meanline=True)
    axes.yaxis.grid(True)  # 加水平网格线
    axes.set_ylabel('Time')  # 设置y轴名称
    axes.set_xlabel('iteration')  # 设置x轴名称

    path_name = "time_box"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_energy_converging2(energy_converging, params):
    # 传进来参数
    Energy = energy_converging

    # 画布
    if params["ONE_FIGURE"] == False:
        # fig, ax = setup_plots(suptitle)
        plt.rc('font', family='serif')
        plt.rc('font', size=38)
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')

        fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(16, 12))
        # fig.suptitle(suptitle)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    # plt.xlabel('iterations', fontweight='normal')
    # plt.ylabel('time', fontweight='normal')

    axes.boxplot(Energy, boxprops={'facecolor': 'orange'}, vert=True, patch_artist=True, showmeans=True, meanline=True)
    axes.yaxis.grid(True)  # 在y轴上添加网格线
    axes.set_ylabel('Energy')  # 设置y轴名称
    axes.set_xlabel('iteration')  # 设置x轴名称

    path_name = "energy_box"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_payment_converging2(pricing_converging, params):
    # 传进来参数-
    Payment = pricing_converging

    # 画布
    if params["ONE_FIGURE"] == False:
        # fig, ax = setup_plots(suptitle)
        plt.rc('font', family='serif')
        plt.rc('font', size=38)
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')

        fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(16, 12))
        # fig.suptitle(suptitle)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    axes.boxplot(Payment, boxprops={'facecolor': 'mediumseagreen'}, vert=True, patch_artist=True, showmeans=True, meanline=True)
    axes.yaxis.grid(True)  # 在y轴上添加网格线
    axes.set_ylabel('Payment')  # 设置y轴名称
    axes.set_xlabel('iteration')  # 设置x轴名称

    path_name = "payment_box"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_expected_utility_converging2(expected_utility_converging, params):
    # 传进来参数
    Utility = expected_utility_converging

    # 画布
    if params["ONE_FIGURE"] == False:
        # fig, ax = setup_plots(suptitle)
        plt.rc('font', family='serif')
        plt.rc('font', size=38)
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')

        fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(16, 12))
        # fig.suptitle(suptitle)

    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    # plt.xlabel('iterations', fontweight='normal')
    # plt.ylabel('time', fontweight='normal')

    axes.boxplot(Utility, boxprops={'facecolor': 'gold'}, vert=True, patch_artist=True, showmeans=True, meanline=True)
    axes.yaxis.grid(True)  # 在y轴上添加网格线
    axes.set_ylabel('Utility')   # 设置y轴名称
    axes.set_xlabel('iteration')  # 设置x轴名称

    path_name = "utility_box"
    if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
        plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    else:
        plt.show(block=False)

def plot_original(b_converging, times_converging, energy_converging, pricing_converging, expected_utility_converging, PoF_converging, params):
    # colors = ['gold', 'mediumpurple', 'mediumseagreen', 'cornflowerblue', 'orange', 'hotpink']
    # line_types = ['-', '*', 'o', 'p', 'D', '-.']

    plt.rc('font', family='serif')
    # plt.rc('font', size=38)    #  2行3列
    plt.rc('font', size=28)    #  3行2列
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 18))
    # grid = plt.GridSpec(2, 3, wspace=0.27, hspace=0.4)     #  2行3列
    grid = plt.GridSpec(3, 2, wspace=0.3, hspace=0.45)       #  3行2列

    # fig = plt.figure(num=5, figsize=(24, 18), dpi=80)
    axes1 = plt.subplot(grid[0, 0])
    # axes1 = fig.add_subplot(2, 2, 1)
    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    # axes1.set_title('(a)', y=-0.33, fontsize='small')    #  2行3列
    axes1.set_title('(a)', y=-0.38, fontsize='small')    # 3行2列
    axes1.yaxis.grid(True)  # 加水平网格线
    axes1.set_ylabel('Offloaded Data')  # 设置y轴名称
    axes1.set_xlabel('Iteration')  # 设置x轴名称

    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    Offloadingdata = b_converging
    labelss = np.arange(0, 15)
    axes1.boxplot(Offloadingdata, vert=True, patch_artist=True, showmeans=True, meanline=True)
    # axes1.boxplot(Offloadingdata, labels ={'0','1','2','3','4','5','6','7','8','9','10','11','12','13','14'}, boxprops={'facecolor': 'white'}, vert=True, patch_artist=True, showmeans=True, meanline=True,)
    axes1.boxplot(Offloadingdata,
                  labels=labelss,
                  boxprops={'facecolor': 'white'}, vert=True, patch_artist=True, showmeans=True, meanline=True)

    # 子图2
    # axes2 = fig.add_subplot(3, 3, 3)
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    # axes2.set_title('(b)', y=-0.36, fontsize='small')  #  2行3列
    axes2.set_title('(b)', y=-0.38, fontsize='small')  #  3行2列
    axes2.yaxis.grid(True)  # 在y轴上添加网格线
    axes2.set_ylabel('Utility')  # 设置y轴名称
    axes2.set_xlabel('Iteration')  # 设置x轴名称
    axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    Utility = expected_utility_converging
    axes2.boxplot(Utility, vert=True, patch_artist=True, showmeans=True, meanline=True)
    axes2.boxplot(Utility,
                  labels=labelss,
                  boxprops={'facecolor': 'white'}, vert=True, patch_artist=True, showmeans=True, meanline=True, )

    # 子图3
    # axes3 = fig.add_subplot(3, 3, 6)
    axes3 = plt.subplot(grid[1, 0])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes3.set_title('(c)', y=-0.38, fontsize='small')
    axes3.yaxis.grid(True)  # 加水平网格线
    axes3.set_ylabel('Delay')  # 设置y轴名称
    axes3.set_xlabel('Iteration')  # 设置x轴名称
    axes3.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    Time = times_converging
    axes3.boxplot(Time, vert=True, patch_artist=True, showmeans=True,meanline=True)
    axes3.boxplot(Time,
                  labels=labelss,
                  boxprops={'facecolor': 'white'}, vert=True, patch_artist=True, showmeans=True, meanline=True)

    # 子图4
    #  axes4 = fig.add_subplot(3, 3, 7)
    axes4 = plt.subplot(grid[1, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes4.set_title('(d)', y=-0.38, fontsize='small')
    axes4.yaxis.grid(True)  # 在y轴上添加网格线
    axes4.set_ylabel('Energy Consumption')  # 设置y轴名称
    axes4.set_xlabel('Iteration')  # 设置x轴名称
    axes4.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    Energy = energy_converging
    axes4.boxplot(Energy, vert=True, patch_artist=True, showmeans=True, meanline=True)
    axes4.boxplot(Energy,
                  labels=labelss,
                  boxprops={'facecolor': 'white'}, vert=True, patch_artist=True, showmeans=True, meanline=True)

    # 子图5
    # axes5 = fig.add_subplot(3, 3, 8)
    axes5 = plt.subplot(grid[2, 0])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes5.set_title('(e)', y=-0.38, fontsize='small')
    axes5.yaxis.grid(True)  # 在y轴上添加网格线
    axes5.set_ylabel('Payment')  # 设置y轴名称
    axes5.set_xlabel('Iteration')  # 设置x轴名称
    axes5.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    Payment = pricing_converging
    axes5.boxplot(Payment, vert=True, patch_artist=True, showmeans=True,meanline=True)
    axes5.boxplot(Payment,
                  labels=labelss,
                  boxprops={'facecolor': 'white'}, vert=True, patch_artist=True, showmeans=True, meanline=True)

    # 子图6
    axes6 = plt.subplot(grid[2, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes6.set_title('(f)', y=-0.38, fontsize='small')
    axes6.set_xlabel('Iteartion')
    axes6.set_ylabel('Pr')
    axes6.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    PoF = PoF_converging
    PoF = np.transpose(PoF)
    line = plt.plot(PoF, '-.', lw=4, color='hotpink')

    path_name = "original"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    plt.savefig("plots/" + path_name + ".png", bbox_inches='tight', dpi=600, pad_inches=0.1)



plot_PoF_div_PoF_weight()