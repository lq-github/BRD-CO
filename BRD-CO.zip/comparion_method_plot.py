import numpy as np
import matplotlib.pyplot as plt
import dill
import matplotlib.lines as mlines
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA
from mpl_toolkits.axes_grid1 import host_subplot
def Utility_and_ω_N():
    colors = ['mediumpurple', 'hotpink', 'mediumseagreen', 'cornflowerblue', 'orange' ]
    line_types = ['v-', 'd-','^-','.-','*-']
    # line_types = ['1-', '2-', '3-', '4-', 'x-']
    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')

    # host.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)

    plt.figure(figsize=(16, 6))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])
    # axes1 = fig.add_subplot(2, 2, 1)
    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    x = np.linspace(0.001,0.9,20)

    #设置图形宽度
    bar_width = 0.2
    X_R = np.arange(len(x))  # R条形图的横坐标
    X_F = X_R + bar_width  # F条形图的横坐标
    X_L = X_R + bar_width*2
    X_G = X_R + bar_width*3
    X_L_MOODO = X_R + bar_width*4
    X_F_MOODO = X_R + bar_width*5

    axes1.set_title('(a)', y=-0.3, fontsize='small')
    axes1.set_ylabel('Average Utility')
    axes1.set_xlabel('ω')
    # axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    #
    # axes1.set_xticks(X_R)
    # # axes1.set_xticklabels(np.linspace(0.1,1,5))
    # axes1.set_xticklabels(x,rotation=45)

    L_MOODO = np.array([0.262534711,0.263799693,0.265008736,0.265792956,0.266281275,
                       0.266549027,0.266643931,0.266598052,0.266433871,0.266167678,
                       0.265811558,0.265374626,0.264863836,0.264284524,0.263640777,
                       0.262935687,0.262171549,0.261350001,0.260472109,0.259538605])
    F_MOODO = np.array([0.261905566,0.263835547,0.26507234,0.265876116,0.266378885,
               0.26665774,0.266761423,0.267621628,0.267461022,0.267197374,
               0.266842938,0.266406975,0.265896559,0.265317082,0.264672695,
               0.263966547,0.263201005,0.262377938,0.261498188,0.260562334])
    L = np.zeros(20)
    F = np.array([-1.398703573,-1.508269501,-1.59620703,-1.670336096,-1.734801186,
         -1.792085244,-1.84380249,-1.894387852,-1.938258261,-1.979045829,
         -2.017216632,-2.053136525,-2.087098407,-2.119340751,-2.150060562,
         -2.179422672,-2.207566559,-2.234611448,-2.260660184,-2.285802229])
    G = np.array([0.231069918,0.229420714,0.228333446,0.226646134,0.225043587,
         0.223584827,0.22224305,0.211557689,0.209922353,0.208338621,
         0.206797266,0.205291535,0.203816924,0.202371146,0.200954961,
         0.19957555,0.198224278,0.196541037,0.194855088,0.193163566])
    R = np.array([-0.190679003,-0.266418646,-0.319362337,-0.358669098,-0.405034591,
         -0.444793508,-0.471663264,-0.491071045,-0.520378183,-0.543414683,
         -0.568475971,-0.59985494,-0.620521097,-0.633590892,-0.655885367,
         -0.676267283,-0.706866005,-0.705533716,-0.736497284,-0.744900983])

    # line1 = axes1.bar(X_F, F, width=bar_width, align='center',label="F. Offl.",color=colors[0])
    # line2 = axes1.bar(X_R, R, width=bar_width, align='center',label="R. Offl.",color=colors[1])
    # line3 = axes1.bar(X_L, L, width=bar_width, align='center',label="L. Offl.",color=colors[2])
    # line4 = axes1.bar(X_G, G, width=bar_width, align='center',label="G. Offl.",color=colors[3])
    # line5 = axes1.bar(X_L_MOODO, L_MOODO,width=bar_width, align='center', label="L-MOODO",color=colors[4])
    # line6, = axes1.bar(X_F_MOODO, F_MOODO,width=bar_width, align='center', color=colors[5])

    line1, = axes1.plot(x, F, line_types[0], lw=2, label="F. Offl.",color=colors[0])
    line2, = axes1.plot(x, R, line_types[1], lw=2, label="R. Offl.",color=colors[1])
    line3, = axes1.plot(x, L, line_types[2], lw=2, label="L. Offl.",color=colors[2])
    line4, = axes1.plot(x, G, line_types[3], lw=2, label="G. Offl.", color=colors[3])
    line5, = axes1.plot(x, L_MOODO, line_types[4], lw=2, label="RM-OCO",color=colors[4])
    # line6, = axes1.plot(x, F_MOODO, line_types[5], lw=4, label="M-MOODO",color=colors[5])

    # plt.legend(handles=[grey_lines, black_line], loc=1, prop={'size': 24})
    plt.legend(loc=3, prop={'size': 16},ncol=1)

    # 子图2
    # axes2 = fig.add_subplot(3, 3, 3)
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.3, fontsize='small')
    axes2.set_ylabel('Average Utility')
    axes2.set_xlabel('Number of users')

    Ns = [1, 2, 5, 15, 25, 35, 45, 55, 65, 75, 85, 100]
    L_MOODO = np.array([2.328816033, 1.947532076, 1.206692781, 0.459031983, 0.267207231,
                        0.182130822, 0.138205205, 0.109151788, 0.089981571, 0.076747769,
                        0.066147508, 0.054706305])
    L = np.zeros(12)
    F = np.array([2.318979885, 1.932249307, 0.871703159, -1.065093047, -2.036730373,
                  -2.380031107, -2.483302586, -2.523678504, -2.522233099, -2.548788366,
                  -2.536447295, -2.538993241])
    G = np.array([2.31957765, 1.933489143, 1.084664855, 0.361729919, 0.216122779,
                  0.15057793, 0.11580008, 0.091781629, 0.076554625, 0.065274924,
                  0.05635218, 0.047450699])
    R = np.array([2.010670593, 1.739401167, 1.05934424, 0.207648966, -0.615342474,
                  -1.175160807, -1.540544988, -1.810748758, -1.923460345, -2.012498333,
                  -2.052265776, -2.093198862])

    line1, = axes2.plot(Ns, F, line_types[0], lw=2, label="F. Offl.", color=colors[0])
    line2, = axes2.plot(Ns, R, line_types[1], lw=2, label="R. Offl.", color=colors[1])
    line3, = axes2.plot(Ns, L, line_types[2], lw=2, label="L. Offl.", color=colors[2])
    line4, = axes2.plot(Ns, G, line_types[3], lw=2, label="G. Offl.", color=colors[3])
    line5, = axes2.plot(Ns, L_MOODO, line_types[4], lw=2, label="RM-OCO", color=colors[4])

    path_name = "comparion_method1"
    plt.legend(loc=3, prop={'size': 16},ncol=1)
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    plt.savefig("plots/" + path_name + ".png", bbox_inches='tight', dpi=600, pad_inches=0.1)

def leidatu_TEP():
    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')

    # labels = ['Average Time', 'Average Energy' + '\n' + 'Consumption', 'Average Payment', 'failure probability' + '\n' + 'of edge server','risk weight']  # 标签
    labels = ['Average Time', 'Average Energy' + '\n' + 'Consumption', 'Average Payment']  # 标签

    # legend = ["F. Offl.", "R. Offl.", "L. Offl.", "G. Offl.", "L-MOODO"]
    # results = np.array([[0.177323588,401.4883718,345.4226359,0.165853851,0.230033993],
    #                     [85.82860515,222.6657361,173.0939412,0.722016642,0.607438359],
    #                     [168.1685728,40.00205942,0,0,0],
    #                     [142.6317344,103.6016325,59.76916383,0.30835415,0.333094861],
    #                     [119.1471464,142.6599145,98.17613454,0.376217343,0.376714912]])

    results = np.array([[0.177323588, 401.4883718, 345.4226359],
                        [85.82860515, 222.6657361, 173.0939412],
                        [168.1685728, 40.00205942, 0],
                        [142.6317344, 103.6016325, 59.76916383],
                        [119.1471464, 142.6599145, 98.17613454]])

    # results_0 = [11, 12, 1]
    # results_1 = [55, 23, 46]
    # labels_length = len(labels)
    # print(labels_length)
    #     print(results.shape[0])
    # 将极坐标根据数据长度进行等分
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False)  # 将圆根据标签的个数等比分
    # print(angles)
    # labels = [key for key in results[0].keys()]
    # score = [[v for v in result.values()] for result in results]
    # 使雷达图数据封闭

    angles = np.concatenate((angles, [angles[0]]))
    results = np.concatenate((results, results[:, [0]]), axis=1)
    #     a = results.shape[0]
    #     print(np.shape(a))
    # results_0 = np.concatenate((results_0, [results_0[0]]))
    # results_1 = np.concatenate((results_1, [results_1[0]]))
    #     for j in  range(0,2):
    #         results_j = np.concatenate((results_j, [results_j[0]]))

    # 设置图形的大小
    fig = plt.figure(figsize=(8,6))
    # 新建一个子图
    ax = plt.subplot(111, polar=True)

    # 绘制雷达图
    colors = ['b', 'r', 'g', 'm', 'y']
    legend = ["F. Offl.", "R. Offl.", "L. Offl.", "G. Offl.", "L-MOODO"]
    for i in range(len(results)):
        ax.plot(angles, results[i], 'o-', color=colors[i], linewidth=1.5, label=legend[i])
        ax.fill(angles, results[i], color=colors[i], alpha=0.5)

    # 设置雷达图中每一项的标签显示
    ax.set_thetagrids(angles * 180 / np.pi, labels)
    # 设置雷达图的0度起始位置
    ax.set_theta_zero_location('N')
    # 设置雷达图的坐标刻度范围
    ax.set_rlim(0, 450)
    # 设置雷达图的坐标值显示角度，相对于起始角度的偏移量
    ax.set_rlabel_position(270)

    plt.legend(loc=1,prop={'size': 12},ncol=1)
    path_name = 'leidatu_TEP'
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    # plt.show()

def plot_N_and_payment_b(cs, expected_utility):
    line_types = ['-', '-']
    colors = ["royalblue", "mediumpurple"]
    colors = ["royalblue", "k"]

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')

    plt.figure(figsize=(16, 4.8))
    # grid = plt.GridSpec(2, 2, wspace=0.3, hspace=0.4)
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    # axes2 = plt.subplot(grid[0, 1])
    # bwith = 2
    # ax = plt.gca()  # 获取边框
    # ax.spines['bottom'].set_linewidth(bwith)
    # ax.spines['left'].set_linewidth(bwith)
    # ax.spines['top'].set_linewidth(bwith)
    # ax.spines['right'].set_linewidth(bwith)
    # axes2.set_title('(b)', y=-0.33, fontsize='small')
    # axes2.set_ylabel('Average Utility')
    # axes2.set_xlabel('ω(N=55)')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # result1 = expected_utility
    # result1 = np.transpose(result1)
    # expected_utility = np.mean(result1, axis=0)
    # line1, = axes2.plot(cs, expected_utility, line_types[0], lw=4, label="expected utility", color=colors[0])



    axes1 = plt.subplot(grid[0, 0])
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(c)', y=-0.33, fontsize='small')
    axes1.set_ylabel('Average Utility')
    axes1.set_xlabel('ω(N=95)')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result1 = expected_utility
    result1 = np.transpose(result1)
    expected_utility = np.mean(result1, axis=0)
    line1, = axes1.plot(cs, expected_utility, line_types[0], lw=4, label="expected utility", color=colors[0])
    #
    # 子图4
    axes4 = plt.subplot(grid[0, 1])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes4.set_title('(d)', y=-0.33, fontsize='small')
    axes4.set_ylabel('ω')
    axes4.set_xlabel('Number of users')
    # axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    Ns = [5, 15,
            25, 35, 45, 55,
            65, 75, 85,95]
    payment_factor = [0.001, 0.23758,
                      0.29236, 0.32906, 0.34234,0.35016,
                      0.35868,0.36625,0.36785,0.36910]
    # payment_factor = [0.001, 0.001, 0.23758, 0.28489,
    #                   0.33221, 0.33221, 0.33221, 0.33221,
    #                   0.37953, 0.37953, 0.37953, 0.37953, 0.37953]
    line1, = axes4.plot(Ns, payment_factor, line_types[1], lw=4, label="offloading data", color=colors[1])

    path_name = "N_and_payment_b5"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

    # axes2 = plt.subplot(grid[0, 1])
    # ax = plt.gca()  # 获取边框
    # ax.spines['bottom'].set_linewidth(bwith)
    # ax.spines['left'].set_linewidth(bwith)
    # ax.spines['top'].set_linewidth(bwith)
    # ax.spines['right'].set_linewidth(bwith)
    # axes2.set_title('(b)', y=-0.33, fontsize='small')
    # axes2.set_xlabel('Number of users')
    # axes2.set_ylabel('Average Offloaded Data')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # Ns = [1, 2, 5, 15, 25, 35, 45, 55, 65, 75, 85, 95, 100]
    # offloaded_data=[10004121.44648275,10044122.63921948,8254389.06838952,4495017.15940339,
    #                 2998772.06807634,2261512.12652891,1813288.21522333,1511623.10261604,
    #                 1277341.53686927,1118786.06754878,996058.07124396,896697.37223504,853666.11193446]
    # line2, = axes2.plot(Ns, offloaded_data, line_types[1], lw=4, markersize=10,label="offloading data", color=colors[1])

Utility_and_ω_N()
# leidatu_TEP()


### PLOT DIFFERENT C #####
case = {"users": "homo"}
repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda1 = 1
lambda2 = 0.001
lambda3 = 0.1
gama = 0.61
kesi2 = 0.69


N = 95
an = 0.2
kn = 1.2
cs = np.linspace(0.001,0.9,20)
for c in cs:
    infile1 = 'saved_runs/results/individual/different c N95/' + case["users"] + \
    "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
    str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
    str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
    str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
    str(round(c, 5)) + "_" + str(repetition)

    with open(infile1, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        times.append(kati["times"].copy())
        # time = kati["time"]
        # PoFWeight.append(kati["PoFWeight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())

        params = kati["params"]

plot_N_and_payment_b(cs,expected_utility)
