'''
Game theory functions
博弈理论函数
'''

import numpy as np
from scipy.optimize import fminbound
import math
import matplotlib.pyplot as plt
import pdb
import time


# 卸载博弈
def play_offloading_game(b, a, bn, dn, an, kn, lambda1, lambda2, lambda3, kexi, fln, gln, PM_c,
                         gama, kesi2, fmn, gmn, fixed_transm_rate, fixed_transm_power, **params):
    b_new = np.empty_like(b)
    expected_utility = np.empty_like(b)

    # N = 10000
    # plt.figure(figsize=(40.0, 30.0))

    for i in range(len(b)):
        # find best response of each one based on utility
        # 根据效用找出每种方法的最佳对策
        # https://vimsky.com/examples/usage/python-scipy.optimize.fminbound.html
        # https://www.pythonheidong.com/blog/article/404146/8130b379c1d7222b5239/
        b_new[i], expected_utility[i], _, _ = fminbound(utility_function, 0, bn[i],
                                                        args=(i, b, a, dn, bn, an, lambda1, lambda2, lambda3, kn, kexi, fln, gln, PM_c,
                                                              gama, kesi2, fmn, gmn, fixed_transm_rate, fixed_transm_power),
                                                        disp=False,
                                                        full_output=True)
        b[i] = b_new[i]

        # calculate utility for ploting
        # x = np.linspace(0, bn[i], N)
        # res = np.empty_like(x)

        # for j in range(len(x)):
        #     res[j] = -utility_function(x[j], i, b, dn, bn, an, kn, c, tn, en)

        # plt.subplot(5,1,i+1)
        # plt.plot(x, res)

    # plt.show(block=False)

    return b_new, -expected_utility


# 博弈收敛
def game_converged(b, b_old, e1, **params):
    '''
    Check if the game has converged

    Parameters
    ----------

    b: 1-D array 用户在最后一次博弈中选择的卸载值
        The offloading values the users chose on the last game
    b_old: 1-D array 用户在之前博弈中选择的卸载值
        The offloading values the users chose on the previous game
    e1: float 用户卸载收敛错误
        Error for user offloading convergence

    Returns
    -------

    convergence: Boolean
        Boolean on whether all users are sure of the selected server or not
    '''

    # e1 is the error tolerance defined in parameters
    # el错误容忍参数
    # all（）方法，直接比对b矩阵和b_old矩阵的所有对应的元素是否相等
    if (np.abs(b - b_old) < e1).all():
        return True
    return False

# 权重函数
def PoFWeight(is_surv,p,gama,kesi2):
    a = gama if is_surv else kesi2
    # if is_surv:
    #     a = gama
    # else:
    #     a = kesi2
    return (p ** a)/(((p ** a)+((1-p) ** a))**(1/a))

# 效用函数
def utility_function(x, i, b, a, dn, bn, an, lambda1, lambda2, lambda3, kn, kexi, fln, gln, PM_c,
                     gama,kesi2,fmn, gmn, fixed_transm_rate, fixed_transm_power, **params): #修改过(所有用到该函数的地方，注意是否需要做相应的调整）
    # ATTENTION here all variables are np.arrays
    # EXCEPT from x and i which are single values

    # replace user's i offloading value
    # 替换用户的第i个卸载值
    b_replaced = np.copy(b)
    b_replaced[i] = x

    u = b_replaced / bn

    # 本地

    e_l = dn[i] * gln[i]   # 本地计算能量
    t_l = dn[i] / fln[i]     # 本地计算时间
    # cc_l = (1-u[i]) *PL_c * dn[i] / fln[i]
    # ce_l = (1-u[i]) *PL_e * dn[i] * gln[i]

    # 服务器
    ttt_m = bn[i] / fixed_transm_rate    # 服务器传输时间
    ete_m = fixed_transm_power * bn[i] / fixed_transm_rate   # 服务器传输能量
    tct_m = dn[i] / fmn[i]    # 计算时间
    ece_m = dn[i] * gmn[i]    # 计算能量
    cpro_m = tct_m * PM_c     # 处理花费

    # ct_m = u[i] * PM_t * bn[i] / fixed_transm_rate
    # cet_m = u[i] * PM_e * fixed_transm_power * bn[i] / fixed_transm_rate
    # cc_m = u[i] * PM_c * dn[i] / fmn[i]
    # ce_m = u[i] * PM_e * dn[i] * gmn[i]

    # 服务器总能量
    e_m = ete_m + ece_m
    # 服务器的总时间
    t_m = ttt_m + tct_m

    # 卸载后的总时间和总能量
    t_po = max(u[i] * t_m, (1-u[i]) * t_l)
    e_po = u[i] * e_m + (1-u[i]) * e_l
    c_po = u[i] * cpro_m[i]                         # 修改过

    # A = ((e_l-e_m) * lambda2)/(lambda3 * tct_m)
    A = ((t_l - t_m) * lambda1 + (e_l - e_m) * lambda2) / (lambda3 * tct_m)

    # ===================================================
    # A = (kexi*bn[i]-(1-u[i]) * c_l)/(u[i] * c_m)
    # reduce_time = t_l - t_po
    # profits = kexi*bn[i]-c_po
    # # print('比值：', A)
    print("---------------------------")
    print('比值：', A)
    print('单价：', PM_c)
    print('时间：', (t_l - t_po) * lambda1)
    print('能量：', (e_l - e_po) * lambda2)
    # print('服务器计算时间：', tct_m)

    print('盈利：', (kexi * np.log(1+bn[i])-c_po) * lambda3)
    print('参考点', kexi * np.log(1 + bn[i]) * lambda3)
    print("---------------------------")
    # a = reduce_time * lambda1
    # b = (u[i] * lambda2 * (2 * ce_l - cte_m - 3 * cce_m))
    # c = a / b
    # print('cpar：', c)

    # ===================================================

    # dt = 1/(1+np.exp(-1.2e-11*np.sum(dn*b_replaced/bn)))
    dt = -1 + 2 / (1 + np.exp(-2.0e-11 * np.sum(dn * b_replaced / bn)))

    Pr = dt ** 2

    # P_surv = (kexi * bn[i] - ((1-u[i]) * tc_l + tc_m) - (kexi * bn[i] - tc_l))**an[i]
    # P_surv = (u[i] * tc_l + tc_m) ** an[i]
    # P_surv = (u[i] * (tc_l + tc_m)) ** an[i]
    # P_surv = ((t_l - t_po) * lamuda1 +  u[i] * (ce_l - c_m) * lamuda2) ** an[i]

    reference_point = kexi * np.log(1+bn[i]) * lambda3
    # P_s = ((t_l - t_po) * lambda1 + (e_l - e_po) * lambda2 + (kexi * bn[i]-c_po) * lambda3)-reference_point
    P_s = ((t_l - t_po) * lambda1 + (e_l - e_po) * lambda2 + (kexi * np.log(1+bn[i])-c_po) * lambda3)-reference_point
    # P_s = -(t_po * lambda1 + e_po * lambda2) + (kexi * np.log(1+bn[i])-c_po) * lambda3

    P_surv = np.float(P_s) ** np.float(an[i])


    # P_fail = -kn[i]*((kexi * bn[i] - tc_l) - ((1-u[i])*kexi*bn[i]-((1-u[i])*tc_l+tc_m)))**an[i]
    # P_f = reference_point - ((e_l - e_po) * lambda2 + ((1 - u[i]) * kexi * bn[i] - c_po) * lambda3)
    P_f = reference_point - ((e_l - e_po) * lambda2 + ((1-u[i]) * kexi * np.log(1+bn[i])-c_po) * lambda3)
    # P_f = t_l * lambda1 + e_po * lambda2 - ((1-u[i]) * kexi * np.log(1+bn[i])-c_po) * lambda3
    P_fail = -kn[i] * (P_f ** an[i])
    # ROR = (2-math.exp(dt-1) - 1/(tn[i]*en[i]) - c[i]*dn[i]/bn[i])**an[i]

    # expected_utility = x**an[i] * (ROR * (1 - Pr) - kn[i] * (1/(tn[i]*en[i]) + c[i]*dn[i]/bn[i])**an[i] * Pr)

    expected_utility = P_surv * PoFWeight(True, 1 - Pr,gama,kesi2) + P_fail * PoFWeight(False, Pr,gama,kesi2)
    # expected_utility = P_surv * (1 - Pr) + P_fail * Pr
    # return minus the utility because we will to use a minimization optimization even
    # though we want to maximize the utility
    a[i] = A
    return -expected_utility
