import numpy as np

def para():
    aaa = np.arange(24)
    # print(aaa)
    u = np.ones(24)*2
    bbb = u * aaa
    # print(bbb)
    return locals()

