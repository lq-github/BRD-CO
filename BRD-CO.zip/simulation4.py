# -*- coding: utf-8 -*-
"""
    Pricing_aware_MEC_offloading.simulation
    ~~~~~~~~~~~~~~~~~~~~~~~~~

    Simulation for the Pricing_aware_MEC_offloading

    :copyright: (c) 2019 by Giorgos Mitsis.
    :license: MIT License, see LICENSE for more details.
"""

from parameters4 import *
from pricing_aware_MEC_offloading4 import *

import time
import dill

# Keep only three decimal places when printing numbers
# 打印时，保留三位小数
np.set_printoptions(formatter={'float': lambda x: "{0:0.5f}".format(x)})

case = {"users": "homo"}
# 用户的个数
# Ns = [1,2,5,10,25,50,75,100]
# Ns = [1,10,25,45,65,85,100]
Ns = [1,2,5,15,25,35,45,55,65,75,85,100]
# Ns = random.sample(range(0,150),20)
# Ns = np.linspace(0,150,20)
# Ns = [25]

# 定价因子
# 均匀分布，产生33个0.1-0.9之间的数
# cpars = np.linspace(0.7,0.999,90)
# cpars = np.linspace(0.001,0.9,20)
cpars = [0.5]
# cs = [0.001,0.04831579, 0.09563158, 0.14294737, 0.19026316, 0.23757895,
 # 0.28489474, 0.33221053, 0.37952632, 0.42684211, 0.47415789, 0.52147368,
 # 0.56878947, 0.61610526, 0.66342105]

# 前景理论效用参数
# ans = [0.88]
ans = [0.2]
# ans = np.linspace(0.1,1,10)

# 玩家对收益与损失的敏感性的权重
# kns = [2.25]
kns = [1.2]
# kns = [0.31]
# kns = np.linspace(0.2,2,10)

# 时间参数lambda1, 能量参数lambda2, 费用参数lambda3
lambda1s = [1]
# lambda1s = np.linspace(0.5,1,20)

lambda2s = [0.001]
# lambda2s = np.linspace(0.001,0.1,20)

lambda3s = [0.1]
# lambda3s = np.linspace(0.001,0.1,20)

# 权重参数:
gamas = [0.61]
# gamas = np.linspace(0.41,0.6,30)
# gamas = np.linspace(0.1,1,10)

kesi2s = [0.69]
# kesi2s = np.linspace(0.61,0.81,30)
# kesi2s = np.linspace(0.1,1,10)

for N in Ns:
    # Set random parameter in order to generate the same parameters
    # 设置随机参数，以生成相同的参数
    print("Generating new parameters")
    # 设置随机种子
    np.random.seed()
    # params = set_parameters(homo, N)
    params = set_parameters(case, N)

    print("Number of users: " + str(params["N"]))
    for lambda1 in lambda1s:
        params["lambda1"] = lambda1
        print("lambda1: " + str(params["lambda1"]))
        for lambda2 in lambda2s:
            params["lambda2"] = lambda2
            print("lambda2: " + str(params["lambda2"]))
            for lambda3 in lambda3s:
                params["lambda3"] = lambda3
                print("lambda3: " + str(params["lambda3"]))
                for gama in gamas:
                    params["gama"] = gama
                    print("gama: " + str(params["gama"]))
                    for kesi2 in kesi2s:
                        params["kesi2"] = kesi2
                        print("kesi2: " + str(params["kesi2"]))
                        for an in ans:
                            params["an"] = an * np.ones(N)
                            print("Sensitivity an: " + str(params["an"][0]))
                            for kn in kns:
                                params["kn"] = kn * np.ones(N)
                                print("Sensitivity kn: " + str(params["kn"][0]))
                                for cpar in cpars:

                                    # params["cpar"] = cpar   # 价格系数c
                                    # params["PM_c"] = cpar * 500  # 服务器计算能量
                                    params["PM_c"] = cpar * params["A"]  # 服务器计算能量
                                    # params["c"] = cpar * params["bn"]/params["dn"] * (1 - (1/(params["tn"]*params["en"])))
                                    # 本地定价：计算定价（$/s)---------------------------------------------------
                                    # params["PL_c"] = 1e6+ np.random.uniform(-1, 1, size=N) * 1e6
                                    # params["PL_c"] = 1e6
                                    # 本地定价：能量定价（$/J)---------------------------------------------------
                                    # params["PL_e"] = 1.5 * 1e5+ np.random.uniform(-1, 1, size=N) * 1e5
                                    # params["PL_e"] = 1.5 * 1e5
                                    # params["PL_e"] = 1.5    # 本地定价：能量定价（$/J)
                                    # 服务器定价：计算定价（$/s)---------------------------------------------------
                                    # params["PM_c"] = cpar * 3.6 * 1e6
                                    # 服务器定价：能量定价（$/J)---------------------------------------------------
                                    # params["PM_te"] = cpar * 2.5 * 1e5  # 服务器定价：传输能量（$/J)
                                    # params["PM_ce"] = cpar * 4.5 * 1e5  # 服务器定价：计算能量（$/J)
                                    # params["PM_te"] = 1  # 传输能量
                                    # params["PM_ce"] = cpar * 4  # 服务器计算能量
                                    # 服务器定价：传输定价（$/s)---------------------------------------------------
                                    # params["PM_t"] = cpar * 1e5

                                    print("Cost parameter: "+ str(params["cpar"]))

                                    # if bpars is -1 we don't want constant offloading
                                    bpars = [-1,0,0.5,1] if params["CONSTANT_OFFLOADING"] else [-1]

                                    while bpars:
                                        bpar = bpars.pop()
                                        params["bpar"] = bpar

                                        # if bpar is -1 then we don't want constant offloading
                                        if bpar == -1:
                                            params["CONSTANT_OFFLOADING"] = False
                                            params["bpar"] = 0

                                        for repetition in range(1):
                                            print("Repetition no: " + str(repetition+1))

                                            # results = {}

                                            start = time.time()

                                            # Run main simulation
                                            results = main(params)
                    # ------------------------------------------------------------------------------
                                            # check_all_parameters(**params)
                                            # check_best_parameters(**params)

                                            end = time.time()
                                            running_time = end - start
                                            print("Time of simulation:")
                                            print(running_time)


                                            results["N"] = N
                                            results["time"] = running_time
                                            results["repetition"] = repetition

                                            if params["SAVE_RESULTS"] == True:
                                                if params["CONSTANT_OFFLOADING"]:
                                                    constant_str = "_b_constant_" + str(round(bpar,3))
                                                else:
                                                    constant_str = ""
                                                outfile = 'saved_runs/results/individual/random' + case["users"] + constant_str +\
                                                          "_N_" + str(N) + "_lambda1_" + str(round(lambda1,3))+"_lambda2_" +\
                                                          str(round(lambda2,3))+ "_lambda3_" + str(round(lambda3,3))+"_gama_" +\
                                                          str(round(gama,3))+"_kesi2_" + str(round(kesi2,3))+ "_an_" + \
                                                          str(round(an,3)) + "_kn_" + str(round(kn,3)) + "_c_" + \
                                                          str(round(cpar,5)) + "_" + str(repetition)

                                                with open(outfile, 'wb') as fp:
                                                    dill.dump(results, fp)
                                                with open(outfile+".csv", "w") as fp_compare:
                                                    save_list = ["expected_utility_converging","pricing_converging",  "energy_converging", "times_converging"]
                                                    for list_name in save_list:
                                                        fp_compare.write(list_name+"\n")
                                                        temp_str = "\n".join([",".join(list(map(str, i))) for i in results[list_name]])

                                                        fp_compare.write(temp_str+"\n")
                                                        fp_compare.write(",".join(list(map(str, np.mean(results[list_name], axis=0))))+"\n")
                                                        fp_compare.write(str(np.mean(results[list_name]))+"\n")

                                                    for list_name in ["PoF_converging", "Pof_weight_converging"]:
                                                        fp_compare.write(list_name + "\n")
                                                        temp_str = ",".join(list(map(str,  results[list_name])))
                                                        fp_compare.write(temp_str+"\n")



if params["GENERATE_FIGURES"] and not params["SAVE_FIGS"]:
    plt.show()
