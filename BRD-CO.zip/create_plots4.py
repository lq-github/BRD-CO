import dill
import numpy as np
import pprint
import math

from plots import *
from cycler import cycler
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA

def plot_b_constant_all(b_constant_all, params):
    '''
    Plot the data each user is trying to offload till convergence
    绘制每个用户试图卸载的数据直到收敛
    Parameters
    ----------

    b_till_convergence: 2-d array
    Contains on each row the amount of data each user is trying to offload. Each row is
    a different iteration
    每行包含每个用户试图卸载的数据量。每一行都是不同的迭代

    Returns
    -------
    Plot

    '''
    result = b_constant_all

    # Each row on the transposed matrix contains the data the user offloads
    # in each iteration. Different rows mean different user.
    result = np.transpose(result)

    suptitle = "Expected utility when everybody is offloading a constant amount of data"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    for index, row in enumerate(result):
        # # display only some of the users on the plot
        # if index%11 == 0:
        #     line = plt.plot(row, lw=4)
        line = plt.plot(row, lw=1)

    plt.xlabel('Amount of data * 10^6', fontweight='normal')
    plt.ylabel('Expected utility', fontweight='normal')

    path_name = "b_till_convergence"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".png")

def plot_different_c_converging(expected_utility_converging, b_converging, pricing_converging, params):

    suptitle = "Average expected utility, b and pricing"

    if params["ONE_FIGURE"] == False:
        fig, ax1 = setup_plots(suptitle)

    ax1.set_xlabel('iterations', fontweight='normal')
    ax1.set_ylabel('expected utility', fontweight='normal')

    ax2 = ax1.twinx() # instantiate a second axes that shares the same x-axis
    ax3 = ax1.twinx() # instantiate a third axes that shares the same x-axis

    ax2.set_ylabel('b', fontweight='normal')
    ax3.set_ylabel('pricing', fontweight='normal')

    ax1.set_prop_cycle(cycler('color', ['b','g','r']))
    ax2.set_prop_cycle(cycler('color', ['b','g','r']))
    ax3.set_prop_cycle(cycler('color', ['b','g','r']))

    for i in range(len(expected_utility_converging)):
        result1 = expected_utility_converging[i]
        result2 = b_converging[i]
        result3 = pricing_converging[i]

        result1 = np.transpose(result1)
        result2 = np.transpose(result2)
        result3 = np.transpose(result3)

        expected_utility_converging[i] = np.mean(result1, axis=0)
        line = ax1.plot(expected_utility_converging[i], '-', lw=4)

        b_converging[i] = np.mean(result2, axis=0)
        line = ax2.plot(b_converging[i], '--', lw=4)

        pricing_converging[i] = np.mean(result3, axis=0)
        line = ax3.plot(pricing_converging[i], ':', lw=4)

    # ax1.ticklabel_format(style='sci', axis='y', scilimits=(6, 6), useMathText=True)
    # ax2.ticklabel_format(style='sci', axis='y', scilimits=(6, 6), useMathText=True)
    # ax3.ticklabel_format(style='sci', axis='y', scilimits=(6, 6), useMathText=True)


    path_name = "different_c_converging"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".png")

def plot_different_c_b_converging(b_converging, params):

    suptitle = "b converging for different c"

    if params["ONE_FIGURE"] == False:
        fig, ax1 = setup_plots(suptitle)

    ax1.set_xlabel('iterations', fontweight='normal')
    ax1.set_ylabel('offloading data', fontweight='normal')

    ax1.set_prop_cycle(cycler('color', ['b','g','r']))
    line = []
    for i in range(len(b_converging)):
        result1 = b_converging[i]
        # 矩阵的转置操作
        result1 = np.transpose(result1)

        b_converging[i] = np.mean(result1, axis=0)
        line.append(ax1.plot(b_converging[i], '--', lw=1))

    ax1.ticklabel_format(style='sci', axis='y', scilimits=(6, 6), useMathText=True)

    # grey_lines = mlines.Line2D([], [], lw=2, color='0.5', label='each c')

    # ax1.legend(handles=[grey_lines], loc=4, prop={'size': 24})
    path_name = "different_c_b_converging"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".png")

def plot_different_kn(kns, expected_utility, b, PoF, params):
    colors = ['mediumpurple', 'hotpink']
    line_types = ['*', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 4.8))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('k_${pd_i}$')
    axes1.set_ylabel('Average Offloaded Data')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)
    line1, = axes1.plot(kns, b, line_types[0], lw=4, markersize=10, label="offloading data", color=colors[0])

    # 子图2
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('k_${pd_i}$')
    axes2.set_ylabel('Pr')

    result3 = PoF
    result3 = np.transpose(result3)
    line2, = axes2.plot(kns, PoF, line_types[1], lw=4, label="PoF", color=colors[1])

    path_name = "different_kn1"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

    ###############################################################################
    # # colors = ['k', 'k']
    # colors = ['gold', 'mediumpurple', 'hotpink']
    # line_types = ['-', '*', '-.']
    #
    # plt.rc('font', family='serif')
    # plt.rc('font', size=44)
    # plt.rc('xtick', labelsize='x-small')
    # plt.rc('ytick', labelsize='x-small')
    # # plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
    #
    # suptitle = "Average b and PoF"
    #
    # fig = plt.figure(figsize=(16, 12))
    # # fig.suptitle(suptitle)
    #
    # host = host_subplot(111, axes_class=AA.Axes)
    # plt.subplots_adjust(right=0.8)
    # plt.subplots_adjust(left=0.2)
    #
    # # 创建两个坐标轴
    # par1 = host.twinx()
    # par2 = host.twinx()
    # # 右边第1个轴
    # par1.axis["right"].toggle(all=True)
    # par1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # # 右边第2个轴
    # offset = 160
    # new_fixed_axis = par2.get_grid_helper().new_fixed_axis
    # par2.axis["right"] = new_fixed_axis(loc="right",
    #                                     axes=par2,
    #                                     offset=(offset, 0))
    # par2.axis["right"].toggle(all=True)
    #
    # host.set_xlabel('${k_i}$')
    # host.set_ylabel('Average Utility')
    # par1.set_ylabel('Amount of Offloaded Data')
    # par2.set_ylabel('PoF')
    #
    # result1 = expected_utility
    # result2 = b
    # result3 = PoF
    #
    # result1 = np.transpose(result1)
    # expected_utility = np.mean(result1, axis=0)
    # host.plot(kns, expected_utility, line_types[0], lw=4, label="physician's utility", color=colors[0])
    #
    # result2 = np.transpose(result2)
    # b = np.mean(result2, axis=0)
    # line1, = par1.plot(kns, b, line_types[1], lw=4, markersize=20, label="offloading data", color=colors[1])
    #
    # result3 = np.transpose(result3)
    # line2, = par2.plot(kns, PoF, line_types[2], lw=4, label="PoF", color=colors[2])
    #
    # # host.axis["left"].label.set_color(line1.get_color())
    # # par1.axis["right"].label.set_color(line2.get_color())
    # # par2.axis["right"].label.set_color(line3.get_color())
    #
    # host.legend(loc=2, prop={'size': 24})
    #
    # path_name = "different_kn"
    # # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    # #     plt.savefig("plots/" + path_name + ".png")
    # # else:
    # #     plt.show()
    # plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

def plot_different_an(ans, expected_utility, b, PoF, params):
    colors = ['mediumpurple', 'hotpink']
    line_types = ['*', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 4.8))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('$\\alpha _{p{d_i}}}$')
    axes1.set_ylabel('Average Offloaded Data')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)
    line1, = axes1.plot(ans, b, line_types[0], lw=4, markersize=10, label="offloading data", color=colors[0])

    # 子图2
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('$\\alpha _{p{d_i}}}$')
    axes2.set_ylabel('Pr')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = PoF
    result3 = np.transpose(result3)
    line2, = axes2.plot(ans, PoF, line_types[1], lw=4, label="PoF", color=colors[1])

    path_name = "different_an1"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

    ###############################################################################
    #
    # colors = ['gold', 'mediumpurple', 'hotpink']
    # line_types = ['-', '*', '-.']
    #
    # plt.rc('font', family='serif')
    # plt.rc('font', size=44)
    # plt.rc('xtick', labelsize='x-small')
    # plt.rc('ytick', labelsize='x-small')
    # # plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
    #
    # suptitle = "Average b and PoF"
    #
    # fig = plt.figure(figsize=(16,12))
    # # fig.suptitle(suptitle)
    #
    # host = host_subplot(111, axes_class=AA.Axes)
    # plt.subplots_adjust(right=0.85)
    # plt.subplots_adjust(left=0.2)
    #
    #
    # # 创建两个坐标轴
    # par1 = host.twinx()
    # par2 = host.twinx()
    # # 右边第1个轴
    # par1.axis["right"].toggle(all=True)
    # par1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # # 右边第2个轴
    # offset = 160
    # new_fixed_axis = par2.get_grid_helper().new_fixed_axis
    # par2.axis["right"] = new_fixed_axis(loc="right",
    #                                      axes=par2,
    #                                      offset=(offset, 0))
    # par2.axis["right"].toggle(all=True)
    #
    # host.set_xlabel('$\\alpha _{p{d_i}}}$')
    # host.set_ylabel('Average Utility')
    # par1.set_ylabel('Average Offloaded Data')
    # par2.set_ylabel('Pr')
    #
    # result1 = expected_utility
    # result2 = b
    # result3 = PoF
    #
    # result1 = np.transpose(result1)
    # expected_utility = np.mean(result1, axis=0)
    # host.plot(ans, expected_utility, line_types[0], lw=4, label="physician's utility", color=colors[0])
    #
    # result2 = np.transpose(result2)
    # b = np.mean(result2, axis=0)
    # line1, = par1.plot(ans, b, line_types[1], lw=4, markersize=20, label="offloading data", color=colors[1])
    #
    # result3 = np.transpose(result3)
    # line2, = par2.plot(ans, PoF, line_types[2], lw=4, label="PoF", color=colors[2])
    #
    # # host.axis["left"].label.set_color(line1.get_color())
    # # par1.axis["right"].label.set_color(line2.get_color())
    # # par2.axis["right"].label.set_color(line3.get_color())
    #
    # host.legend(loc=2, prop={'size': 24})
    #
    # path_name = "different_an2"
    # # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    # #     plt.savefig("plots/" + path_name + ".png")
    # # else:
    # #     plt.show()
    # plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

def plot_different_gama(gamas, expected_utility, b, PoF, params):
    colors = ['mediumpurple', 'hotpink']
    line_types = ['*', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 4.8))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('γ')
    axes1.set_ylabel('Average Offloaded Data')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)
    line1, = axes1.plot(gamas, b, line_types[0], lw=4, markersize=10, label="offloading data", color=colors[0])

    # 子图2
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('γ')
    axes2.set_ylabel('Pr')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = PoF
    result3 = np.transpose(result3)
    line2, = axes2.plot(gamas, PoF, line_types[1], lw=4, label="PoF", color=colors[1])

    path_name = "different_gama1"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

    ###############################################################################
    # # colors = ["k", "k"]
    # colors = ['gold', 'mediumpurple', 'hotpink']
    # line_types = ['-', '*', '-.']
    #
    # plt.rc('font', family='serif')
    # plt.rc('font', size=44)
    # plt.rc('xtick', labelsize='x-small')
    # plt.rc('ytick', labelsize='x-small')
    # # plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
    #
    # suptitle = "Average b and PoF"
    #
    # fig = plt.figure(figsize=(16,12))
    # # fig.suptitle(suptitle)
    #
    # host = host_subplot(111, axes_class=AA.Axes)
    # plt.subplots_adjust(right=0.85)
    # plt.subplots_adjust(left=0.2)
    #
    #
    # # 创建两个坐标轴
    # par1 = host.twinx()
    # par2 = host.twinx()
    # # 右边第1个轴
    # par1.axis["right"].toggle(all=True)
    # par1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # # 右边第2个轴
    # offset = 160
    # new_fixed_axis = par2.get_grid_helper().new_fixed_axis
    # par2.axis["right"] = new_fixed_axis(loc="right",
    #                                      axes=par2,
    #                                      offset=(offset, 0))
    # par2.axis["right"].toggle(all=True)
    #
    # host.set_xlabel('γ')
    # host.set_ylabel('Average Utility')
    # par1.set_ylabel('Average Offloaded Data')
    # par2.set_ylabel('Pr')
    #
    # result1 = expected_utility
    # result2 = b
    # result3 = PoF
    #
    # result1 = np.transpose(result1)
    # expected_utility = np.mean(result1, axis=0)
    # host.plot(gamas, expected_utility, line_types[0], lw=4, label="physician's utility", color=colors[0])
    #
    # result2 = np.transpose(result2)
    # b = np.mean(result2, axis=0)
    # line1, = par1.plot(gamas, b, line_types[1], lw=4, markersize=20, label="offloading data", color=colors[1])
    #
    # result3 = np.transpose(result3)
    # line2, = par2.plot(gamas, PoF, line_types[2], lw=4, label="PoF", color=colors[2])
    #
    # # host.axis["left"].label.set_color(line1.get_color())
    # # par1.axis["right"].label.set_color(line2.get_color())
    # # par2.axis["right"].label.set_color(line3.get_color())
    #
    # host.legend(loc=2, prop={'size': 24})
    #
    # path_name = "different_gama2"
    # # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    # #     plt.savefig("plots/" + path_name + ".png")
    # # else:
    # #     plt.show()
    # plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    #

def plot_different_kesi2(kesi2s, expected_utility, b, PoF, params):
    colors = ['mediumpurple', 'hotpink']
    line_types = ['*', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 4.8))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('δ')
    axes1.set_ylabel('Average Offloaded Data')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)
    line1, = axes1.plot(kesi2s, b, line_types[0], lw=4, markersize=10, label="offloading data", color=colors[0])

    # 子图2
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('δ')
    axes2.set_ylabel('Pr')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = PoF
    result3 = np.transpose(result3)
    line2, = axes2.plot(kesi2s, PoF, line_types[1], lw=4, label="PoF", color=colors[1])

    path_name = "different_kesi2s1"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

###############################################################################
    # # colors = ["k", "k"]
    # colors = ['gold', 'mediumpurple', 'hotpink']
    # line_types = ['-', '*', '-.']
    #
    # plt.rc('font', family='serif')
    # plt.rc('font', size=44)
    # plt.rc('xtick', labelsize='x-small')
    # plt.rc('ytick', labelsize='x-small')
    # # plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
    #
    # suptitle = "Average b and PoF"
    #
    # fig = plt.figure(figsize=(16,12))
    # # fig.suptitle(suptitle)
    #
    # host = host_subplot(111, axes_class=AA.Axes)
    # plt.subplots_adjust(right=0.85)
    # plt.subplots_adjust(left=0.2)
    #
    #
    # # 创建两个坐标轴
    # par1 = host.twinx()
    # par2 = host.twinx()
    # # 右边第1个轴
    # par1.axis["right"].toggle(all=True)
    # par1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # # 右边第2个轴
    # offset = 160
    # new_fixed_axis = par2.get_grid_helper().new_fixed_axis
    # par2.axis["right"] = new_fixed_axis(loc="right",
    #                                      axes=par2,
    #                                      offset=(offset, 0))
    # par2.axis["right"].toggle(all=True)
    #
    # host.set_xlabel('δ')
    # host.set_ylabel('Average Utility')
    # par1.set_ylabel('Average Offloaded Data')
    # par2.set_ylabel('Pr')
    #
    # result1 = expected_utility
    # result2 = b
    # result3 = PoF
    #
    # result1 = np.transpose(result1)
    # expected_utility = np.mean(result1, axis=0)
    # host.plot(kesi2s, expected_utility, line_types[0], lw=4, label="physician's utility", color=colors[0])
    #
    # result2 = np.transpose(result2)
    # b = np.mean(result2, axis=0)
    # line1, = par1.plot(kesi2s, b, line_types[1], lw=4, markersize=20, label="offloading data", color=colors[1])
    #
    # result3 = np.transpose(result3)
    # line2, = par2.plot(kesi2s, PoF, line_types[2], lw=4, label="PoF", color=colors[2])
    #
    # # host.axis["left"].label.set_color(line1.get_color())
    # # par1.axis["right"].label.set_color(line2.get_color())
    # # par2.axis["right"].label.set_color(line3.get_color())
    #
    # host.legend(loc=2, prop={'size': 24})
    #
    # path_name = "different_kesi2s2"
    # # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    # #     plt.savefig("plots/" + path_name + ".png")
    # # else:
    # #     plt.show()
    # plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

def plot_different_c(cs, expected_utility, b, pricing, times, energy, params):

    # colors = ['k','0.7','0.5']
    # line_types = ['--', '-', ':']
    colors = ['gold', 'mediumpurple', 'mediumseagreen', 'cornflowerblue', 'orange']
    line_types = ['-', '*', 'o', 'p', 'D']

    plt.rc('font', family='serif')
    plt.rc('font', size=44)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))

    # 标题
    suptitle = "Average expected utility, b and pricing"

    # 画图
    # fig = plt.figure(figsize=(16,14))
    # fig.suptitle(suptitle)
    fig, axes = plt.subplots(nrows=3, ncols=2, figsize=(16, 12))

    host = host_subplot(111, axes_class=AA.Axes)
    plt.subplots_adjust(right=0.75)

    par1 = host.twinx() # instantiate a 2 axes that shares the same x-axis
    par2 = host.twinx() # instantiate a 3 axes that shares the same x-axis
    par3 = host.twinx() # instantiate a 4 axes that shares the same x-axis
    par4 = host.twinx()  # instantiate a 5 axes that shares the same x-axis

    # 右边第1个轴
    par1.axis["right"].toggle(all=True)

    # 右边第2个轴
    offset = 160
    new_fixed_axis = par2.get_grid_helper().new_fixed_axis
    par2.axis["right"] = new_fixed_axis(loc="right",
                                        axes=par2,
                                        offset=(offset, 0))
    par2.axis["right"].toggle(all=True)

    # 右边第3个轴
    offset = 320
    new_fixed_axis = par3.get_grid_helper().new_fixed_axis
    par3.axis["right"] = new_fixed_axis(loc="right",
                                        axes=par3,
                                        offset=(offset, 0))
    par3.axis["right"].toggle(all=True)

    # 右边第4个轴
    offset = 480
    new_fixed_axis = par3.get_grid_helper().new_fixed_axis
    par4.axis["right"] = new_fixed_axis(loc="right",
                                        axes=par4,
                                        offset=(offset, 0))
    par4.axis["right"].toggle(all=True)


    par1.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True)
    par2.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True, useOffset=True, useLocale=True)
    par3.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True, useOffset=True, useLocale=True)
    par4.ticklabel_format(style='sci', axis='y', scilimits=(0,0), useMathText=True, useOffset=True, useLocale=True)

    host.set_xlabel('Pricing Factor')
    host.set_ylabel('Average Expected Utility')
    par1.set_ylabel('Average Offloaded Data')
    par2.set_ylabel('Average Pricing')
    par3.set_ylabel('Average Time')
    par4.set_ylabel('Average Energy')

    result1 = expected_utility
    result2 = b
    result3 = pricing
    result4 = times
    result5 = energy

    result1 = np.transpose(result1)
    result2 = np.transpose(result2)
    result3 = np.transpose(result3)
    result4 = np.transpose(result4)
    result5 = np.transpose(result5)

    expected_utility = np.mean(result1, axis=0)
    line1, = host.plot(cs, expected_utility, line_types[0], lw=4, label="expected utility", color=colors[0])

    b = np.mean(result2, axis=0)
    line2, = par1.plot(cs, b, line_types[1], lw=4, label="data", color=colors[1])

    pricing = np.mean(result3, axis=0)
    line3, = par2.plot(cs, pricing, line_types[2], lw=4, label="pricing", color=colors[2])

    time = np.mean(result4, axis=0)
    # time = result4/25
    print('time:', time)
    line4, = par3.plot(cs, time, line_types[3], lw=4, label="time", color=colors[3])

    energy = np.mean(result5, axis=0)
    print('energy:',energy)
    line5, = par4.plot(cs, energy, line_types[4], lw=4, label="energy", color=colors[4])

    # host.axis["left"].label.set_color(line1.get_color())
    # par1.axis["right"].label.set_color(line2.get_color())
    # par2.axis["right"].label.set_color(line3.get_color())
    # par3.axis["right"].label.set_color(line4.get_color())

    host.legend(loc=1, prop={'size': 24})

    path_name = "different_c"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".png")

def plot_different_c_subfigure325(cs, expected_utility, b, pricing, times, energy, params):

    # colors = ['k','0.7','0.5']
    # line_types = ['--', '-', ':']
    colors = ['gold', 'mediumpurple', 'mediumseagreen', 'cornflowerblue', 'orange']
    line_types = ['-', '*', 'o', 'p', 'D']

    plt.rc('font', family='serif')
    plt.rc('font', size=20)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))

    # 标题
    suptitle = "Average expected utility, b and pricing"

    # 标题
    suptitle = "Average expected utility, b, pricing, time and energy"

    # 画图
    # fig = plt.figure(figsize=(16,14))
    # fig.suptitle(suptitle)

    fig = plt.figure(num=5, figsize=(24, 18), dpi=80)
    # 子图1
    axes1 = fig.add_subplot(3, 2, 1)
    axes1.set_xlabel('Pricing Factor')
    axes1.set_ylabel('Average Expected Utility')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result1 = expected_utility
    result1 = np.transpose(result1)
    expected_utility = np.mean(result1, axis=0)
    line1, = axes1.plot(cs, expected_utility, line_types[0], lw=4, label="expected utility", color=colors[0])
    # axes1.legend(loc=1, prop={'size': 24})

    # 子图2
    axes2 = fig.add_subplot(3, 2, 3)
    axes2.set_xlabel('Pricing Factor')
    axes2.set_ylabel('Average Offloaded Data')
    axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)
    line2, = axes2.plot(cs, b, line_types[1], lw=4, label="data", color=colors[1])

    # 子图3
    axes3 = fig.add_subplot(3, 2, 4)
    axes3.set_xlabel('Pricing Factor')
    axes3.set_ylabel('Average Pricing')
    axes3.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = pricing
    result3 = np.transpose(result3)
    pricing = np.mean(result3, axis=0)
    line3, = axes3.plot(cs, pricing, line_types[2], lw=4, label="pricing", color=colors[2])

   # 子图4
    axes4 = fig.add_subplot(3, 2, 5)
    axes4.set_xlabel('Pricing Factor')
    axes4.set_ylabel('Average Times')
    axes4.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result4 = times
    result4 = np.transpose(result4)
    times = np.mean(result4, axis=0)
    line4, = axes4.plot(cs, times, line_types[3], lw=4, label="times", color=colors[3])

    # 子图5
    axes5 = fig.add_subplot(3, 2, 6)
    axes5.set_xlabel('Pricing Factor')
    axes5.set_ylabel('Average Energy')
    axes4.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result5 = energy
    result5 = np.transpose(result5)
    energy = np.mean(result5, axis=0)
    line5, = axes5.plot(cs, energy, line_types[4], lw=4, label="energy", color=colors[4])

    path_name = "different_c"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".png")



    # # host.axis["left"].label.set_color(line1.get_color())
    # # par1.axis["right"].label.set_color(line2.get_color())
    # # par2.axis["right"].label.set_color(line3.get_color())
    # # par3.axis["right"].label.set_color(line4.get_color())
    #
    # host.legend(loc=1, prop={'size': 24})
    #
    # path_name = "different_c"
    # # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    # #     plt.savefig("plots/" + path_name + ".png")
    # # else:
    # #     plt.show()
    # plt.savefig("plots/" + path_name + ".png")

def plot_different_c_subfigure32(cs, expected_utility, b, pricing, times, energy,PoFweight,PoF, params):

    # colors = ['k','0.7','0.5']
    # line_types = ['--', '-', ':']
    colors = ['gold', 'mediumpurple', 'mediumseagreen', 'cornflowerblue', 'orange', 'hotpink']
    line_types = ['-', '*', 'o', 'p', 'D', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))

    # 画图
    plt.figure(figsize=(16,12))
    # fig.suptitle(suptitle)
    # plt.subplots(nrows=3, ncols=2, figsize=(16, 12))

    host1 = host_subplot(111, axes_class=AA.Axes)
    # plt.subplots_adjust(right=0.75)

    par1 = host1.twinx()  # instantiate a 2 axes that shares the same x-axis

    # 右边第1个轴
    par1.axis["right"].toggle(all=True)

    par1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    host1.set_xlabel('Pricing Factor')
    host1.set_ylabel('PoF')
    par1.set_ylabel('PoFweight')

    result6 = PoF
    result7 = PoFweight
    result6 = np.transpose(result6)
    result7 = np.transpose(result7)
    # PoF = np.mean(result6, axis=0)
    line1, = host1.plot(cs, result6, line_types[0], lw=4, label="PoF", color=colors[0])

    # PoFweight = np.mean(result7, axis=0)
    line2, = par1.plot(cs, result7, line_types[1], lw=4, markersize=10, label="PoFweight", color=colors[1])

    host1.legend(loc=1, prop={'size': 18})

    path_name = "different_c2"
    plt.savefig("plots/" + path_name + ".svg")





    # 标题
    suptitle = "Average expected utility, b and pricing"

    # 标题
    suptitle = "Average expected utility, b, pricing, time and energy"

    # 画图
    # fig = plt.figure(figsize=(16,14))
    # fig.suptitle(suptitle)

    # 子图1
    plt.figure(figsize=(16, 18))
    grid = plt.GridSpec(3, 2, wspace=0.3, hspace=0.4)


    # fig = plt.figure(num=5, figsize=(24, 18), dpi=80)
    axes1 = plt.subplot(grid[0, 0])
    # axes1 = fig.add_subplot(2, 2, 1)
    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)

    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('ω')
    axes1.set_ylabel('Average Utility')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result1 = expected_utility
    result1 = np.transpose(result1)
    expected_utility = np.mean(result1, axis=0)
    print(np.max(expected_utility))
    print(np.where(expected_utility==np.max(expected_utility)))
    # print(cs[np.where(expected_utility==np.max(expected_utility))])
    line1, = axes1.plot(cs, expected_utility, line_types[0], lw=4, label="expected utility", color=colors[0])
    # axes1.legend(loc=1, prop={'size': 24})

    # 子图2
    # axes2 = fig.add_subplot(3, 3, 3)
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('ω')
    axes2.set_ylabel('Average Offloaded Data')
    axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)

    print(b[np.where(expected_utility==np.max(expected_utility))])
    line2, = axes2.plot(cs, b, line_types[1], lw=4, markersize=10, label="offloaded data", color=colors[1])

    # 子图3
    # axes3 = fig.add_subplot(3, 3, 6)
    axes3 = plt.subplot(grid[1, 0])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes3.set_title('(c)', y=-0.35, fontsize='small')
    axes3.set_xlabel('ω')
    axes3.set_ylabel('Average Delay')
    axes3.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = times
    result3 = np.transpose(result3)
    times = np.mean(result3, axis=0)
    line3, = axes3.plot(cs, times, line_types[2], lw=4, label="time", color=colors[2])

   # 子图4
   #  axes4 = fig.add_subplot(3, 3, 7)
    axes4 = plt.subplot(grid[1, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes4.set_title('(d)', y=-0.35, fontsize='small')
    axes4.set_xlabel('ω')
    axes4.set_ylabel('Average Energy'+'\n'+'Consumption')
    axes4.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result4 = energy
    result4 = np.transpose(result4)
    energy = np.mean(result4, axis=0)
    line4, = axes4.plot(cs, energy, line_types[3], lw=4, markersize=8, label="energy", color=colors[3])

    # 子图5
    # axes5 = fig.add_subplot(3, 3, 8)
    axes5 = plt.subplot(grid[2, 0])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes5.set_title('(e)', y=-0.35, fontsize='small')
    axes5.set_xlabel('ω')
    axes5.set_ylabel('Average Payment')
    axes5.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result5 = pricing
    result5 = np.transpose(result5)
    pricing = np.mean(result5, axis=0)
    line5, = axes5.plot(cs, pricing, line_types[4], lw=4, label="pricing", color=colors[4])

    axes6 = plt.subplot(grid[2, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes6.set_title('(f)', y=-0.35, fontsize='small')
    axes6.set_xlabel('ω')
    axes6.set_ylabel('Pr')
    axes6.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result6 = PoF
    result6 = np.transpose(result6)
    # PoF = np.mean(result6, axis=0)
    line1, = axes6.plot(cs,result6 , line_types[5], lw=4, label="PoF", color=colors[5])

    path_name = "different_c1"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    plt.savefig("plots/" + path_name + ".png", bbox_inches='tight', dpi=600, pad_inches=0.1)

def plot_different_N(Ns, expected_utility, b, pricing, params):

    # colors = ['k','0.7','0.5']
    # line_types = ['--', '-', ':']
    colors = ['darkorange','royalblue','darkgreen']
    line_types = ['-', '-', '-']

    plt.rc('font', family='serif')
    plt.rc('font', size=44)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))

    suptitle = "Average expected utility, b and pricing"

    fig = plt.figure(figsize=(15,12))
    # fig.suptitle(suptitle)

    host = host_subplot(111, axes_class=AA.Axes)
    plt.subplots_adjust(right=0.75)

    par1 = host.twinx() # instantiate a second axes that shares the same x-axis
    par2 = host.twinx() # instantiate a third axes that shares the same x-axis

    par1.axis["right"].toggle(all=True)

    offset = 160
    new_fixed_axis = par2.get_grid_helper().new_fixed_axis
    par2.axis["right"] = new_fixed_axis(loc="right",
                                        axes=par2,
                                        offset=(offset, 0))

    par2.axis["right"].toggle(all=True)

    par1.ticklabel_format(style='sci', axis='y', scilimits=(7,7), useMathText=True)
    par2.ticklabel_format(style='sci', axis='y', scilimits=(7,7), useMathText=True)

    host.set_xlabel('Number of Users')
    host.set_ylabel('Average Expected Utility')
    par1.set_ylabel('Average Offloaded Data')
    par2.set_ylabel('Average Pricing')

    result1 = expected_utility
    result2 = b
    result3 = pricing

    result1 = np.transpose(result1)
    result2 = np.transpose(result2)
    result3 = np.transpose(result3)

    # expected_utility = np.mean(result1, axis=0)
    line1, = host.plot(Ns, expected_utility, line_types[0], lw=4, label="expected utility", color=colors[0])

    # b = np.mean(result2, axis=0)
    line2, = par1.plot(Ns, b, line_types[1], lw=4, label="data", color=colors[1], alpha=0.7)

    # pricing = np.mean(result3, axis=0)
    line3, = par2.plot(Ns, pricing, '--', lw=4, label="pricing", color=colors[2])

    # host.axis["left"].label.set_color(line1.get_color())
    # par1.axis["right"].label.set_color(line2.get_color())
    # par2.axis["right"].label.set_color(line3.get_color())

    host.legend(loc=1, prop={'size': 24})

    path_name = "different_N"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".png")

def plot_different_N_subfigure32(Ns, expected_utility, b, pricing, times, energy,PoFweight,PoF, params):

    # colors = ['k','0.7','0.5']
    # line_types = ['--', '-', ':']
    colors = ['gold', 'mediumpurple', 'mediumseagreen', 'cornflowerblue', 'orange', 'hotpink']
    line_types = ['-', '*', 'o', 'p', 'D', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))

    # 画图
    plt.figure(figsize=(16,12))
    # fig.suptitle(suptitle)
    # plt.subplots(nrows=3, ncols=2, figsize=(16, 12))

    host1 = host_subplot(111, axes_class=AA.Axes)
    # plt.subplots_adjust(right=0.75)

    par1 = host1.twinx()  # instantiate a 2 axes that shares the same x-axis

    # 右边第1个轴
    par1.axis["right"].toggle(all=True)

    par1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    host1.set_xlabel('Number of users')
    host1.set_ylabel('PoF')
    par1.set_ylabel('PoFweight')

    result6 = PoF
    result7 = PoFweight
    result6 = np.transpose(result6)
    result7 = np.transpose(result7)
    # PoF = np.mean(result6, axis=0)
    line1, = host1.plot(Ns, result6, line_types[0], lw=4, label="PoF", color=colors[0])

    # PoFweight = np.mean(result7, axis=0)
    line2, = par1.plot(Ns, result7, line_types[1], lw=4, markersize=10, label="PoFweight", color=colors[1])

    host1.legend(loc=1, prop={'size': 20})

    path_name = "different_N2"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)






    # 标题
    suptitle = "Average expected utility, b and pricing"

    # 标题
    suptitle = "Average expected utility, b, pricing, time and energy"

    # 画图
    # fig = plt.figure(figsize=(16,14))
    # fig.suptitle(suptitle)

    # 子图1
    plt.figure(figsize=(16, 18))
    grid = plt.GridSpec(3, 2, wspace=0.3, hspace=0.4)


    # fig = plt.figure(num=5, figsize=(24, 18), dpi=80)
    axes1 = plt.subplot(grid[0, 0])
    # axes1 = fig.add_subplot(2, 2, 1)
    # 加粗边框
    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('Number of users')
    axes1.set_ylabel('Average Utility')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)

    result1 = expected_utility
    result1 = np.transpose(result1)
    # expected_utility = np.mean(result1, axis=0)
    # expected_utility = np.concatenate(result1, axis=0)
    line1, = axes1.plot(Ns, expected_utility, line_types[0], lw=4, label="expected utility", color=colors[0])


    # 子图2
    # axes2 = fig.add_subplot(3, 3, 3)
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('Number of users')
    axes2.set_ylabel('Average Offloaded Data')
    axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    # b = np.mean(result2, axis=0)
    line2, = axes2.plot(Ns, b, line_types[1], lw=4, markersize=10, label="offloaded data", color=colors[1])

    # 子图3
    # axes3 = fig.add_subplot(3, 3, 6)
    axes3 = plt.subplot(grid[1, 0])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes3.set_title('(c)', y=-0.35, fontsize='small')
    axes3.set_xlabel('Number of users')
    axes3.set_ylabel('Average Time')
    axes3.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = times
    result3 = np.transpose(result3)
    # times = np.mean(result3, axis=0)
    line3, = axes3.plot(Ns, times, line_types[2], lw=4, label="time", color=colors[2])

   # 子图4
   #  axes4 = fig.add_subplot(3, 3, 7)
    axes4 = plt.subplot(grid[1, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes4.set_title('(d)', y=-0.35, fontsize='small')
    axes4.set_xlabel('Number of users ')
    axes4.set_ylabel('Average Energy'+'\n'+'Consumption')
    axes4.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result4 = energy
    result4 = np.transpose(result4)
    # energy = np.mean(result4, axis=0)
    line4, = axes4.plot(Ns, energy, line_types[3], lw=4, markersize=8, label="energy", color=colors[3])

    # 子图5
    # axes5 = fig.add_subplot(3, 3, 8)
    axes5 = plt.subplot(grid[2, 0])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes5.set_title('(e)', y=-0.35, fontsize='small')
    axes5.set_xlabel('Number of users')
    axes5.set_ylabel('Average Payment')
    axes5.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result5 = pricing
    result5 = np.transpose(result5)
    # pricing = np.mean(result5, axis=0)
    line5, = axes5.plot(Ns, pricing, line_types[4], lw=4, label="pricing", color=colors[4])

    axes6 = plt.subplot(grid[2, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes6.set_title('(f)', y=-0.35, fontsize='small')
    axes6.set_xlabel('Number of users')
    axes6.set_ylabel('Pr')
    axes6.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result6 = PoF
    result6 = np.transpose(result6)
    # PoF = np.mean(result6, axis=0)
    line1, = axes6.plot(Ns, result6, line_types[5], lw=4, label="PoF", color=colors[5])

    path_name = "different_N1"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    plt.savefig("plots/" + path_name + ".png", bbox_inches='tight', dpi=600, pad_inches=0.1)

def plot_different_N_b_converging(Ns, b_converging, params):

    suptitle = "j converging for different number of users"

    if params["ONE_FIGURE"] == False:
        fig, ax1 = setup_plots(suptitle)

    ax1.set_xlabel('iterations', fontweight='normal')
    ax1.set_ylabel('Average Offloading Data', fontweight='normal')

    colors = ['k', '0.3', '0.4', '0.5','0.55','0.6','0.7','0.8']

    for i in range(len(b_converging)):
        result1 = b_converging[i]

        result1 = np.transpose(result1)

        b_converging[i] = np.mean(result1, axis=0)
        line = ax1.plot(b_converging[i], '-', lw=4, color=colors[i])

        plt.text(len(b_converging[i]) + 2, b_converging[i][-1], "N = " + str(Ns[i]), fontsize=24)

    plt.ticklabel_format(style='sci', axis='y', scilimits=(7,7), useMathText=True)

    path_name = "different_N_b_converging"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show()
    plt.savefig("plots/" + path_name + ".png")

def plot_different_N_FuC(Ns, PoF, params):

    suptitle = "FuC"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    FuC = PoF/PoF[0]

    line = plt.plot(Ns, FuC, '--', lw=4, color='black')

    plt.xlabel('Number of Users', fontweight='normal')
    plt.ylabel('FuC', fontweight='normal')

    path_name = "FuC_vs_N"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_N_an_FuC(ans, Ns, PoFs, params):

    suptitle = "FuC"

    # colors = ["0.2", "0.2", "0.2"]
    colors = ["indianred", "brown", "darkred"]
    lines = ["-", "-", "-"]
    marker = ["o", "v", "s"]
    labels = ["α\u2099 = 0.2", "α\u2099 = 0.5", "α\u2099 = 0.8"]

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    for index, an in enumerate(ans):

        FuC = PoFs[index]/PoFs[index][0]

        line = plt.plot(Ns, FuC, lines[index], marker=marker[index], markersize=14, label=labels[index] ,lw=4, color=colors[index])

    plt.xlabel('Number of Users', fontweight='normal')
    plt.ylabel('FuC', fontweight='normal')

    plt.legend(loc=4, prop={'size': 24})

    # current_handles, current_labels = plt.gca().get_legend_handles_labels()

    # # sort or reorder the labels and handles
    # reversed_handles = list(reversed(current_handles))
    # reversed_labels = list(reversed(current_labels))

    # # call plt.legend() with the new values
    # plt.legend(reversed_handles,reversed_labels, loc=2, prop={'size': 24})

    path_name = "FuC_vs_N_ans"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_N_kn_FuC(kns, Ns, PoFs, params):

    suptitle = "FuC"

    # colors = ['0.2', '0.2', '0.2']
    marker = ["o", "v", "s"]
    colors = ['limegreen', 'forestgreen', 'darkgreen']
    lines = ["-", "-", "-"]
    labels = ["k\u2099 = 0.8", "k\u2099 = 1.2", "k\u2099 = 2.0"]

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    for index, an in enumerate(kns):

        FuC = PoFs[index]/PoFs[index][0]

        line = plt.plot(Ns, FuC, lines[index], marker=marker[index], markersize=14, label=labels[index] ,lw=4, color= colors[index])

    plt.xlabel('Number of Users', fontweight='normal')
    plt.ylabel('FuC', fontweight='normal')

    plt.legend(loc=4, prop={'size': 24})

    path_name = "FuC_vs_N_kns"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_c_PoF(cs, PoF, params):

    suptitle = "PoF"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    line = plt.plot(cs, PoF, '--', lw=4, color='black')

    plt.xlabel('Pricing Factor', fontweight='normal')
    plt.ylabel('PoF', fontweight='normal')

    path_name = "PoF_vs_cost"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_c_energy(cs, energy, params):

    suptitle = "energy"

    result = energy
    result = np.transpose(result)
    energy = np.mean(result, axis=0)

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    line = plt.plot(cs, energy, '--', lw=4, color='black')

    plt.xlabel('Pricing Factor', fontweight='normal')
    plt.ylabel('energy', fontweight='normal')

    path_name = "energy_vs_cost"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_c_time(cs, time, params):

    suptitle = "time"

    result = time
    result = np.transpose(result)
    energy = np.mean(result, axis=0)

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    line = plt.plot(cs, energy, '--', lw=4, color='black')

    plt.xlabel('Pricing Factor', fontweight='normal')
    plt.ylabel('energy', fontweight='normal')

    path_name = "time_vs_cost"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_an_PoF(ans, PoF, params):

    suptitle = "PoF"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    line = plt.plot(ans, PoF, '--', lw=4, color='black')

    plt.xlabel('Sensitivity α\u2099')
    plt.ylabel('PoF', fontweight='normal')

    path_name = "PoF_vs_an"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_kn_PoF(kns, PoF, params):

    suptitle = "PoF"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    line = plt.plot(kns, PoF, '--', lw=4, color='black')

    plt.xlabel('Sensitivity k\u2099', fontweight='normal')
    plt.ylabel('PoF', fontweight='normal')

    path_name = "PoF_vs_kn"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_offloading(offloadings, energy, params):

    suptitle = "different offloading energies"

    if params["ONE_FIGURE"] == False:
        fig, ax = setup_plots(suptitle)

    result = energy
    result = np.transpose(result)
    mean_energy = np.mean(result, axis=0)

    x = np.arange(len(offloadings))

    plt.bar(x, mean_energy, color='0.3')

    labels = ["only local", "50-50", "only server", "dynamic"]
    plt.xticks(x, labels)

    plt.xlabel('Offloading Mechanism', fontweight='normal')
    plt.ylabel('Energy [joules]', fontweight='normal')

    path_name = "offloading_energy_bars"
    # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
    #     plt.savefig("plots/" + path_name + ".png")
    # else:
    #     plt.show(block=False)
    plt.savefig("plots/" + path_name + ".png")

def plot_different_lambda1(lambda1s, expected_utility, b, PoF, params):
    colors = ['mediumpurple', 'hotpink']
    line_types = ['*', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 4.8))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('${λ_1}$')
    axes1.set_ylabel('Average Offloaded Data')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)
    line1, = axes1.plot(lambda1s, b, line_types[0], lw=4, markersize=10, label="offloading data", color=colors[0])
    # line1, = axes1.plot(lambda1s, b, line_types[0], lw=4, label="offloading data", color=colors[0])

    # 子图2
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('${λ_1}$')
    axes2.set_ylabel('Pr')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = PoF
    result3 = np.transpose(result3)
    line2, = axes2.plot(lambda1s, PoF, line_types[1], lw=4, label="PoF", color=colors[1])

    path_name = "different_lambda1-1"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
#################################################################################
    # colors = ['gold', 'mediumpurple', 'hotpink']
    # line_types = ['-', '*', '-.']
    #
    # plt.rc('font', family='serif')
    # plt.rc('font', size=44)
    # plt.rc('xtick', labelsize='x-small')
    # plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
    #
    # # 画图
    # plt.figure(figsize=(16, 12))
    # host1 = host_subplot(111, axes_class=AA.Axes)
    # plt.subplots_adjust(right=0.85)
    # plt.subplots_adjust(left=0.2)
    #
    # # 创建两个坐标轴
    # par11 = host1.twinx()
    # par12 = host1.twinx()
    #
    # # 右边第1个轴
    # par11.axis["right"].toggle(all=True)
    # par11.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # # 右边第2个轴
    # offset = 160
    # new_fixed_axis = par12.get_grid_helper().new_fixed_axis
    # par12.axis["right"] = new_fixed_axis(loc="right",
    #                                     axes=par12,
    #                                     offset=(offset, 0))
    # par12.axis["right"].toggle(all=True)
    #
    #
    # # 加粗边框
    # bwith = 2
    # ax = plt.gca()  # 获取边框
    # ax.spines['bottom'].set_linewidth(bwith)
    # ax.spines['left'].set_linewidth(bwith)
    # ax.spines['top'].set_linewidth(bwith)
    # ax.spines['right'].set_linewidth(bwith)
    #
    # # 设置坐标轴
    # host1.set_xlabel('${λ_1}$')
    # host1.set_ylabel('Average Utility')
    # par11.set_ylabel('Amount of Offloaded Data')
    # par12.set_ylabel('PoF')
    #
    # result11 = expected_utility
    # result11 = np.transpose(result11)
    # expected_utility = np.mean(result11, axis=0)
    # host1.plot(lambda1s, expected_utility, line_types[0], lw=4, label="physician's utility", color=colors[0])
    #
    # result12 = b
    # result12 = np.transpose(result12)
    # b = np.mean(result12, axis=0)
    # par11.plot(lambda1s, b, line_types[1], lw=4, markersize=20, label="offloaded data", color=colors[1])
    #
    # result13 = PoF
    # PoF = np.transpose(result13)
    # par12.plot(lambda1s, PoF, line_types[2], lw=4, label="PoF", color=colors[2])
    #
    # host1.legend(loc=1, prop={'size': 24})
    #
    # path_name = "different_lambda1"
    #
    # plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

def plot_different_lambda2(lambda2s, expected_utility, b, PoF, params):
    colors = ['mediumpurple', 'hotpink']
    line_types = ['*', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 4.8))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('${λ_2}$')
    axes1.set_ylabel('Average Offloaded Data')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)
    line1, = axes1.plot(lambda2s, b, line_types[0], lw=4, markersize=10, label="offloading data", color=colors[0])
    # line1, = axes1.plot(lambda2s, b, line_types[0], lw=4, label="offloading data", color=colors[0])

    # 子图2
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('${λ_2}$')
    axes2.set_ylabel('Pr')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = PoF
    result3 = np.transpose(result3)
    line2, = axes2.plot(lambda2s, PoF, line_types[1], lw=4, label="PoF", color=colors[1])

    path_name = "different_lambda2-1"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    #################################################################################

    # colors = ['gold', 'mediumpurple',  'hotpink']
    # line_types = ['-', '*',  '-.']
    #
    # plt.rc('font', family='serif')
    # plt.rc('font', size=44)
    # plt.rc('xtick', labelsize='x-small')
    # plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
    #
    # # 画图
    # plt.figure(figsize=(16, 12))
    # host2 = host_subplot(111, axes_class=AA.Axes)
    # plt.subplots_adjust(right=0.85)
    # plt.subplots_adjust(left=0.2)
    #
    # # 创建两个坐标轴
    # par21 = host2.twinx()
    # par22 = host2.twinx()
    #
    # # 右边第1个轴
    # par21.axis["right"].toggle(all=True)
    # par21.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # # 右边第2个轴
    # offset = 160
    # new_fixed_axis = par22.get_grid_helper().new_fixed_axis
    # par22.axis["right"] = new_fixed_axis(loc="right",
    #                                      axes=par22,
    #                                      offset=(offset, 0))
    # par22.axis["right"].toggle(all=True)
    #
    # # 加粗边框
    # bwith = 2
    # ax = plt.gca()  # 获取边框
    # ax.spines['bottom'].set_linewidth(bwith)
    # ax.spines['left'].set_linewidth(bwith)
    # ax.spines['top'].set_linewidth(bwith)
    # ax.spines['right'].set_linewidth(bwith)
    #
    # # 设置坐标轴
    # host2.set_xlabel('${λ_2}$')
    # host2.set_ylabel('Average Utility')
    # par21.set_ylabel('Amount of Offloaded Data')
    # par22.set_ylabel('PoF')
    #
    # result21 = expected_utility
    # result21 = np.transpose(result21)
    # expected_utility = np.mean(result21, axis=0)
    # host2.plot(lambda2s, expected_utility, line_types[0], lw=4, label="physician's utility", color=colors[0])
    #
    # result22 = b
    # result22 = np.transpose(result22)
    # b = np.mean(result22, axis=0)
    # par21.plot(lambda2s, b, line_types[1], lw=4, markersize=20, label="offloaded data", color=colors[1])
    #
    # result23 = PoF
    # PoF = np.transpose(result23)
    # par22.plot(lambda2s, PoF, line_types[2], lw=4, label="PoF", color=colors[2])
    #
    # host2.legend(loc=1, prop={'size': 24})
    #
    # path_name = "different_lambda2"
    #
    # plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)

def plot_different_lambda3(lambda3s, expected_utility, b, PoF, params):
    colors = ['mediumpurple', 'hotpink']
    line_types = ['*', '-.']

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.figure(figsize=(16, 4.8))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('${λ_3}$')
    axes1.set_ylabel('Average Offloaded Data')
    axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result2 = b
    result2 = np.transpose(result2)
    b = np.mean(result2, axis=0)
    line1, = axes1.plot(lambda3s, b, line_types[0], lw=4, markersize=10, label="offloading data", color=colors[0])
    # line1, = axes1.plot(lambda3s, b, line_types[0], lw=4, label="offloading data", color=colors[0])

    # 子图2
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('${λ_3}$')
    axes2.set_ylabel('Pr')
    # axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    result3 = PoF
    result3 = np.transpose(result3)
    line2, = axes2.plot(lambda3s, PoF, line_types[1], lw=4, label="PoF", color=colors[1])

    path_name = "different_lambda3-1"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)
    #################################################################################

    # colors = ['gold', 'mediumpurple', 'hotpink']
    # line_types = ['-', '*', '-.']
    #
    # plt.rc('font', family='serif')
    # plt.rc('font', size=44)
    # plt.rc('xtick', labelsize='x-small')
    # plt.rc('ytick', labelsize='x-small')
    # plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
    #
    # # 画图
    # plt.figure(figsize=(16, 12))
    #
    # host3 = host_subplot(111, axes_class=AA.Axes)
    #
    # plt.subplots_adjust(right=0.85)
    # plt.subplots_adjust(left=0.2)
    #
    # # 创建两个坐标轴
    # par31 = host3.twinx()
    # par32 = host3.twinx()
    # # 右边第1个轴
    # par31.axis["right"].toggle(all=True)
    # par31.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # # 右边第2个轴
    # offset = 160
    # new_fixed_axis = par32.get_grid_helper().new_fixed_axis
    # par32.axis["right"] = new_fixed_axis(loc="right",
    #                                      axes=par32,
    #                                      offset=(offset, 0))
    # par32.axis["right"].toggle(all=True)
    #
    # host3.set_xlabel('${λ_3}$')
    # host3.set_ylabel('Average Utility')
    # # host3.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    # par31.set_ylabel('Amount of Offloaded Data')
    # par32.set_ylabel('PoF')
    #
    # result31 = expected_utility
    # result31 = np.transpose(result31)
    # expected_utility = np.mean(result31, axis=0)
    # host3.plot(lambda3s, expected_utility, line_types[0], lw=4, label="physician's utility", color=colors[0])
    #
    # result32 = b
    # result32 = np.transpose(result32)
    # b = np.mean(result32, axis=0)
    # par31.plot(lambda3s, b, line_types[1], lw=4, markersize=20, label="offloaded data", color=colors[1])
    #
    # result33 = PoF
    # PoF = np.transpose(result33)
    # par32.plot(lambda3s, PoF, line_types[2], lw=4, label="PoF", color=colors[2])
    #
    # host3.legend(loc=1, prop={'size': 24})
    #
    # # 加粗边框
    # bwith = 2
    # ax = plt.gca()  # 获取边框
    # ax.spines['bottom'].set_linewidth(bwith)
    # ax.spines['left'].set_linewidth(bwith)
    # ax.spines['top'].set_linewidth(bwith)
    # ax.spines['right'].set_linewidth(bwith)
    #
    # path_name = "different_lambda3"
    # plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)



def plot_N_and_payment_b():
    line_types = ['-', '*']
    colors = ["royalblue", "mediumpurple"]

    plt.rc('font', family='serif')
    plt.rc('font', size=28)
    plt.rc('xtick', labelsize='x-small')
    plt.rc('ytick', labelsize='x-small')

    plt.figure(figsize=(16, 4.8))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)

    axes1 = plt.subplot(grid[0, 0])

    bwith = 2
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes1.set_title('(a)', y=-0.35, fontsize='small')
    axes1.set_xlabel('Number of users')
    axes1.set_ylabel('ω')
    # axes1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    Ns = [1, 2, 5, 15, 25, 35, 45, 55, 65, 75, 85, 95, 100]
    payment_factor = [0.001,0.001,0.23758,0.28489,
                      0.33221,0.33221,0.33221,0.33221,
                      0.37953,0.37953,0.37953,0.37953,0.37953]
    line1, = axes1.plot(Ns, payment_factor, line_types[0], lw=4,label="offloading data", color=colors[0])

    # 子图2
    axes2 = plt.subplot(grid[0, 1])
    ax = plt.gca()  # 获取边框
    ax.spines['bottom'].set_linewidth(bwith)
    ax.spines['left'].set_linewidth(bwith)
    ax.spines['top'].set_linewidth(bwith)
    ax.spines['right'].set_linewidth(bwith)
    axes2.set_title('(b)', y=-0.35, fontsize='small')
    axes2.set_xlabel('Number of users')
    axes2.set_ylabel('Average Offloaded Data')
    axes2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0), useMathText=True)
    Ns = [1, 2, 5, 15, 25, 35, 45, 55, 65, 75, 85, 95, 100]
    offloaded_data=[10004121.44648275,10044122.63921948,8254389.06838952,4495017.15940339,
                    2998772.06807634,2261512.12652891,1813288.21522333,1511623.10261604,
                    1277341.53686927,1118786.06754878,996058.07124396,896697.37223504,853666.11193446]
    line2, = axes2.plot(Ns, offloaded_data, line_types[1], lw=4, markersize=10,label="offloading data", color=colors[1])

    path_name = "N_and_payment_b"
    plt.savefig("plots/" + path_name + ".svg", bbox_inches='tight', dpi=600, pad_inches=0.1)


case = {"users": "homo"}
plot_N_and_payment_b()

# ##### PLOT DIFFERENT an #####

repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda3 = 0.1
lambda1 = 1
lambda2 = 0.001
gama = 0.61
kesi2 = 0.69

N = 25
ans = np.linspace(0.1,1,10)
kn = 1.2
c = 0.5

for an in ans:
    infile = 'saved_runs/results/individual/different ai/' + case["users"] + \
            "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
        str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
        str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
        str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
        str(round(c, 5)) + "_" + str(repetition)

    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        times.append(kati["times"].copy())
        # time = kati["time"]
        # PoFWeight.append(kati["PoFWeight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())


#     # infile = 'saved_runs/results/individual/different an/' + case["users"] + "_N_" + str(N) + "_an_" + str(round(an,3)) + "_kn_" + str(kn) + "_c_" + str(round(c,3)) + "_" + str(repetition)
#     # with open(infile, 'rb') as in_strm:
#     #     kati = dill.load(in_strm)
#     #     expected_utility.append(kati["expected_utility"].copy())
#     #     b.append(kati["b"].copy())
#     #     pricing.append(kati["pricing"].copy())
#     #     PoF.append(kati["PoF"].copy())
#     #     expected_utility_converging.append(kati["expected_utility_converging"].copy())
#     #     b_converging.append(kati["b_converging"].copy())
#     #     pricing_converging.append(kati["pricing_converging"].copy())
#
        params = kati["params"]
plot_different_an(ans, expected_utility, b, PoF, params)
#
# # ##### PLOT DIFFERENT kn #####
repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda3 = 0.1
lambda1 = 1
lambda2 = 0.001
gama = 0.61
kesi2 = 0.69


N = 25
an = 0.2
kns = np.linspace(0.2,2,10)
c = 0.5
for kn in kns:
    infile = 'saved_runs/results/individual/different ki/' + case["users"] + \
             "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
             str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
             str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
             str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
             str(round(c, 5)) + "_" + str(repetition)

    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        times.append(kati["times"].copy())
        # time = kati["time"]
        # PoFWeight.append(kati["PoFWeight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())
        params = kati["params"]
plot_different_kn(kns, expected_utility, b, PoF, params)


#     infile = 'saved_runs/results/individual/different kn/' + case["users"] + "_N_" + str(N) + "_an_" + str(round(an,3)) + "_kn_" + str(round(kn,3)) + "_c_" + str(round(c,3)) + "_" + str(repetition)
#     with open(infile, 'rb') as in_strm:
#         kati = dill.load(in_strm)
#         expected_utility.append(kati["expected_utility"].copy())
#         b.append(kati["b"].copy())
#         pricing.append(kati["pricing"].copy())
#         PoF.append(kati["PoF"].copy())
#         expected_utility_converging.append(kati["expected_utility_converging"].copy())
#         b_converging.append(kati["b_converging"].copy())
#         pricing_converging.append(kati["pricing_converging"].copy())
#
#         params = kati["params"]
# plot_different_kn(kns, b, PoF, params)
#

##### PLOT DIFFERENT gama #####

repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda3 = 0.1
lambda1 = 1
lambda2 = 0.001
gamas = np.linspace(0.1,1,10)
kesi2 = 0.69

N = 25
an = 0.2
kn = 1.2
c = 0.5

for gama in gamas:
    infile = 'saved_runs/results/individual/different gama/' + case["users"] + \
            "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
        str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
        str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
        str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
        str(round(c, 5)) + "_" + str(repetition)

    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        times.append(kati["times"].copy())
        # time = kati["time"]
        # PoFWeight.append(kati["PoFWeight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())


    # infile = 'saved_runs/results/individual/different an/' + case["users"] + "_N_" + str(N) + "_an_" + str(round(an,3)) + "_kn_" + str(kn) + "_c_" + str(round(c,3)) + "_" + str(repetition)
    # with open(infile, 'rb') as in_strm:
    #     kati = dill.load(in_strm)
    #     expected_utility.append(kati["expected_utility"].copy())
    #     b.append(kati["b"].copy())
    #     pricing.append(kati["pricing"].copy())
    #     PoF.append(kati["PoF"].copy())
    #     expected_utility_converging.append(kati["expected_utility_converging"].copy())
    #     b_converging.append(kati["b_converging"].copy())
    #     pricing_converging.append(kati["pricing_converging"].copy())

        params = kati["params"]
plot_different_gama(gamas, expected_utility, b, PoF, params)

##### PLOT DIFFERENT kesi2 #####

repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda3 = 0.1
lambda1 = 1
lambda2 = 0.001
gama = 0.61
kesi2s = np.linspace(0.1,1,10)

N = 25
an = 0.2
kn = 1.2
c = 0.5

for kesi2 in kesi2s:
    infile = 'saved_runs/results/individual/different kesi2/' + case["users"] + \
            "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
        str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
        str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
        str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
        str(round(c, 5)) + "_" + str(repetition)

    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        times.append(kati["times"].copy())
        # time = kati["time"]
        # PoFWeight.append(kati["PoFWeight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())


    # infile = 'saved_runs/results/individual/different an/' + case["users"] + "_N_" + str(N) + "_an_" + str(round(an,3)) + "_kn_" + str(kn) + "_c_" + str(round(c,3)) + "_" + str(repetition)
    # with open(infile, 'rb') as in_strm:
    #     kati = dill.load(in_strm)
    #     expected_utility.append(kati["expected_utility"].copy())
    #     b.append(kati["b"].copy())
    #     pricing.append(kati["pricing"].copy())
    #     PoF.append(kati["PoF"].copy())
    #     expected_utility_converging.append(kati["expected_utility_converging"].copy())
    #     b_converging.append(kati["b_converging"].copy())
    #     pricing_converging.append(kati["pricing_converging"].copy())

        params = kati["params"]
plot_different_kesi2(kesi2s, expected_utility, b, PoF, params)



#### PLOT DIFFERENT N #####
repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda3 = 0.1
lambda1 = 1
lambda2 = 0.001
gama = 0.61
kesi2 = 0.69

Ns = [1,2,5,15,25,35,45,55,65,75,85,95,100]
an = 0.2
kn = 1.2
c = 0.5

for N in Ns:

    infile = 'saved_runs/results/individual/different N/' + case["users"] + \
    "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
    str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
    str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
    str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
    str(round(c, 3)) + "_" + str(repetition)


    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(np.mean(kati["expected_utility"].copy()))
        b.append(np.mean(kati["b"].copy()))
        pricing.append(np.mean(kati["pricing"].copy()))
        energy.append(np.mean(kati["energy"].copy()))
        PoF.append(kati["PoF"].copy())
        times.append(np.mean(kati["times"].copy()))
        PoFweight.append(kati["PoFweight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy() )
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())

        params = kati["params"]
        with open('plots/time', 'a') as f:
            print("N: " + str(kati["N"]) + " -> iterations: " + str(kati["iterations"])+ " -> time: " + str(kati["time"]), file=f)
plot_different_N_subfigure32(Ns, expected_utility, b, pricing, times, energy, PoFweight, PoF, params)
# # # plot_different_N(Ns, expected_utility, b, pricing, params)
# # plot_different_N_b_converging(Ns, b_converging, params)
# # plot_different_N_FuC(Ns, PoF, params)


# repetition = 0
# expected_utility_converging = []
# b_converging = []
# pricing_converging = []
#
# expected_utility = []
# b = []
# pricing = []
# PoF = []
#
# c = 0.5
# an = 0.2
# kn = 1.2
# # kn = 0.31
# Ns = [1,2,5,10,25,50,75,100]
#
# for N in Ns:
#     infile = 'saved_runs/results/individual/different N/' + case["users"] + "_N_" + str(N) + "_an_" + str(an) + "_kn_" + str(kn) + "_c_" + str(c) + "_" + str(repetition)
#     with open(infile, 'rb') as in_strm:
#         kati = dill.load(in_strm)
#         # expected_utility_converging.append(kati["expected_utility_converging"].copy())
#         # b_converging.append(kati["b_converging"].copy())
#         # pricing_converging.append(kati["pricing_converging"].copy())
#         expected_utility.append(np.mean(kati["expected_utility"]).copy())
#         b.append(np.mean(kati["b"]).copy())
#         pricing.append(np.mean(kati["pricing"]).copy())
#         PoF.append(kati["PoF"].copy())
#         expected_utility_converging.append(kati["expected_utility_converging"].copy())
#         b_converging.append(kati["b_converging"].copy())
#         pricing_converging.append(kati["pricing_converging"].copy())
#
#         params = kati["params"]
#         with open('plots/time', 'a') as f:
#             print("N: " + str(kati["N"]) + " -> iterations: " + str(kati["iterations"])+ " -> time: " + str(kati["time"]), file=f)
#
# plot_different_N(Ns, expected_utility, b, pricing, params)
# plot_different_N_b_converging(Ns, b_converging, params)
# plot_different_N_FuC(Ns, PoF, params)

# plot_b_constant_all(b_constant_all)


### PLOT DIFFERENT C #####

repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda1 = 1
lambda2 = 0.001
lambda3 = 0.1
gama = 0.61
kesi2 = 0.69


N = 25
an = 0.2
kn = 1.2
# cs= [0.37953]
# cs = [0.001,0.04831579, 0.09563158, 0.14294737, 0.19026316, 0.23757895,
 # 0.28489474, 0.33221053, 0.37952632, 0.42684211, 0.47415789, 0.52147368,
 # 0.56878947, 0.61610526, 0.66342105]
cs = np.linspace(0.001,0.9,20)
for c in cs:
    infile = 'saved_runs/results/individual/different c/' + case["users"] + \
    "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
    str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
    str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
    str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
    str(round(c, 5)) + "_" + str(repetition)

    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        times.append(kati["times"].copy())
        # time = kati["time"]
        # PoFWeight.append(kati["PoFWeight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())

        params = kati["params"]

# print("b_converging:", b_converging)
# print("pricing_converging:", pricing_converging)
# print("energy_converging:", energy_converging)
# print("expected_utility_converging:", expected_utility_converging)

# plot_different_c(cs, expected_utility, b, pricing, times, energy, params)
plot_different_c_subfigure32(cs, expected_utility, b, pricing, times, energy,PoFweight,PoF, params)
# plot_different_c_PoF(cs, PoF, params)
# plot_different_c_energy(cs,energy, params)
# plot_different_c_b_converging(b_converging, params)
# plot_different_c_converging(expected_utility_converging, b_converging, pricing_converging, params)

# ##### PLOT different offloading mechanisms #####
#
# repetition = 0
# expected_utility_converging = []
# b_converging = []
# pricing_converging = []
#
# expected_utility = []
# b = []
# pricing = []
# PoF = []
#
# user_energies = []
#
# N = 25
# an = 0.2
# kn = 1.2
# c = 0.5
#
# offloadings = ["_b_constant_0", "_b_constant_0.5", "_b_constant_1", ""]
#
# for offloading in offloadings:
#     infile = 'saved_runs/results/individual/different offloading/' + case["users"] + offloading + "_N_" + str(N) + "_an_" + str(an) + "_kn_" + str(kn) + "_c_" + str(round(c,3)) + "_" + str(repetition)
#     with open(infile, 'rb') as in_strm:
#         kati = dill.load(in_strm)
#         expected_utility.append(kati["expected_utility"].copy())
#         b.append(kati["b"].copy())
#         pricing.append(kati["pricing"].copy())
#         PoF.append(kati["PoF"].copy())
#         expected_utility_converging.append(kati["expected_utility_converging"].copy())
#         b_converging.append(kati["b_converging"].copy())
#         pricing_converging.append(kati["pricing_converging"].copy())
#
#         user_energies.append(kati["user_energy"].copy())
#
#         params = kati["params"]
# plot_different_offloading(offloadings, user_energies, params)
#
# ##### PLOT Pr VS x #####
#
# plt.rc('font', family='serif')
# plt.rc('font', size=44)
# plt.rc('xtick', labelsize='x-small')
# plt.rc('ytick', labelsize='x-small')
# fig = plt.figure(figsize=(16,12))
#
# # Provide tick lines across the plot to help viewers trace along
# # the axis ticks.
# plt.grid(True, 'major', 'y', ls='--', lw=.3, c='k', alpha=.3)
#
# # Remove the tick marks; they are unnecessary with the tick lines we just
# # plotted.
# plt.tick_params(axis='both', which='both', bottom=True, top=False,
#     labelbottom=True, left=False, right=False, labelleft=True)
# x = np.linspace(0, 10, 10000)
# Pr = np.empty_like(x)
# dt = np.empty_like(x)
# for i in range(len(x)):
#     dt[i] = -1 + 2/(1+np.exp(-x[i]))
#     Pr[i] = dt[i]**2
# plt.xlabel('x')
# plt.ylabel('Pr')
# plt.plot(x,Pr, color='k')
# # if params["SAVE_FIGS"] == True and params["ONE_FIGURE"] == False:
# #     plt.savefig("plots/Pr_vs_x.png")
# # else:
# #     plt.show()
# plt.savefig("plots/Pr_vs_x.png")
#


# -----------------different lambda1,2,3------------------
##### PLOT DIFFERENT lambda1 #####
repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda1s = np.linspace(0.5,1,20)
# print(lambda1s)
# for i in lambda1s:
#     print(round(i,3))
lambda2 = 0.001
lambda3 = 0.1
gama = 0.61
kesi2 = 0.69

N = 25
an = 0.2
kn = 1.2
c = 0.5

for lambda1 in lambda1s:
    # infile = 'saved_runs/results/individual/different c/' + case["users"] + "_N_" + str(N) + "_an_" + str(an) + "_kn_" + str(kn) + "_c_" + str(round(c,5)) + "_" + str(repetition)

    infile = 'saved_runs/results/individual/different lambda1/' + case["users"] + \
    "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
    str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
    str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
    str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
    str(round(c, 3)) + "_" + str(repetition)


    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        times.append(kati["times"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())

        params = kati["params"]

plot_different_lambda1(lambda1s, expected_utility, b, PoF, params)


# ##### PLOT DIFFERENT lambda2 #####

repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []


expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda2s = np.linspace(0.001,0.1,20)
lambda1 = 1
lambda3 = 0.1
gama = 0.61
kesi2 = 0.69

N = 25
an = 0.2
kn = 1.2
c = 0.5

for lambda2 in lambda2s:

    infile = 'saved_runs/results/individual/different lambda2/' + case["users"] + \
    "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
    str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
    str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
    str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
    str(round(c, 3)) + "_" + str(repetition)

    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        times.append(kati["times"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())

        params = kati["params"]

plot_different_lambda2(lambda2s, expected_utility, b, PoF, params)


##### PLOT DIFFERENT lambda3 #####

repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []
energy_converging = []
times_converging = []
Pof_weight_converging = []

expected_utility = []
b = []
pricing = []
PoF = []
energy = []
PoFweight = []
times = []

lambda3s = np.linspace(0.001,0.1,20)
# print(lambda1s)
# for i in lambda1s:
#     print(round(i,3))
lambda1 = 1
lambda2 = 0.001
gama = 0.61
kesi2 = 0.69

N = 25
an = 0.2
kn = 1.2
c = 0.5

for lambda3 in lambda3s:

    infile = 'saved_runs/results/individual/different lambda3/' + case["users"] + \
    "_N_" + str(N) + "_lambda1_" + str(round(lambda1, 3)) + "_lambda2_" + \
    str(round(lambda2, 3)) + "_lambda3_" + str(round(lambda3, 3)) + "_gama_" + \
    str(round(gama, 3)) + "_kesi2_" + str(round(kesi2, 3)) + "_an_" + \
    str(round(an, 3)) + "_kn_" + str(round(kn, 3)) + "_c_" + \
    str(round(c, 3)) + "_" + str(repetition)


    with open(infile, 'rb') as in_strm:
        kati = dill.load(in_strm)
        expected_utility.append(kati["expected_utility"].copy())
        b.append(kati["b"].copy())
        pricing.append(kati["pricing"].copy())
        energy.append(kati["energy"].copy())
        PoF.append(kati["PoF"].copy())
        times.append(kati["times"].copy())
        PoFweight.append(kati["PoFweight"].copy())
        Pof_weight_converging.append(kati["Pof_weight_converging"].copy())
        expected_utility_converging.append(kati["expected_utility_converging"].copy())
        b_converging.append(kati["b_converging"].copy())
        pricing_converging.append(kati["pricing_converging"].copy())
        energy_converging.append(kati["energy_converging"].copy())
        times_converging.append(kati["times_converging"].copy())

        params = kati["params"]

plot_different_lambda3(lambda3s, expected_utility, b, PoF, params)


# ##### PLOT FuC DIFFERENT N DIFFERENT AN #####
repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []

expected_utility = []
b = []
pricing = []
PoFs = []

c = 0.5
ans = [0.2, 0.5, 0.8]
kn = 1.2
# Ns = [1,2,5,10,25,50,75,100]
Ns = [1,2,5,15,25,35,45,55,65,75,85,95,100]

for an in ans:
    PoF = []
    for N in Ns:
        infile = 'saved_runs/results/individual/different N an/' + case["users"] + "_N_" + str(N) + "_an_" + str(round(an,3)) + "_kn_" + str(kn) + "_c_" + str(c) + "_" + str(repetition)
        with open(infile, 'rb') as in_strm:
            kati = dill.load(in_strm)
            PoF.append(kati["PoF"].copy())

            params = kati["params"]
    PoFs.append(PoF)

plot_different_N_an_FuC(ans, Ns, PoFs, params)
# #
# ##### PLOT FuC DIFFERENT N DIFFERENT KN #####

repetition = 0
expected_utility_converging = []
b_converging = []
pricing_converging = []

expected_utility = []
b = []
pricing = []
PoFs = []

c = 0.5
an = 0.2
kns = [0.8, 1.2, 2.0]
Ns = [1,2,5,10,25,50,75,100]

for kn in kns:
    PoF = []
    for N in Ns:
        infile = 'saved_runs/results/individual/different N kn/' + case["users"] + "_N_" + str(N) + "_an_" + str(round(an,3)) + "_kn_" + str(round(kn,3)) + "_c_" + str(c) + "_" + str(repetition)
        with open(infile, 'rb') as in_strm:
            kati = dill.load(in_strm)
            PoF.append(kati["PoF"].copy())

            params = kati["params"]
    PoFs.append(PoF)

plot_different_N_kn_FuC(kns, Ns, PoFs, params)
#

